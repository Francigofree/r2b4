# R2B4 P0 dual-frame close-out — NO SHA

This package intentionally contains **no commit SHA check and no blob/file SHA check**.

The installer is anchor-based and idempotent:

- old P0 code fragment found -> patch it;
- corrected P0 code fragment already found -> skip it;
- neither form found -> stop for that specific anchor rather than guessing.

## Apply

```bash
rm -rf /tmp/r2b4_p0_close
unzip -o r2b4_p0_localization_close_no_sha_20260928.zip -d /tmp/r2b4_p0_close

python3 \
  /tmp/r2b4_p0_close/r2b4_p0_localization_close_no_sha_20260928/apply_upgrade.py \
  --check /home/alba/project_r2b4

python3 \
  /tmp/r2b4_p0_close/r2b4_p0_localization_close_no_sha_20260928/apply_upgrade.py \
  /home/alba/project_r2b4
```

If all P0 changes are already present, the installer prints:

```text
R2B4_P0_DUAL_FRAME_CLOSE_NO_SHA_20260928: ALREADY_APPLIED
```

## Validate

```bash
bash \
  /tmp/r2b4_p0_close/r2b4_p0_localization_close_no_sha_20260928/verify.sh \
  /home/alba/project_r2b4 --full
```

## P0 scope only

- deep replay capture test uses terminal `PASS`, not `STOP`;
- near command typos are rejected before plain Gemini fallback;
- ordinary free text still reaches the plain Gemini path;
- relative-LiDAR motion is accepted independently of global pose publication;
- global NAVIGATE without `map_to_odom` fails closed with `GLOBAL_TRANSFORM_MISSING`;
- local-frame NAVIGATE remains independent of the global transform;
- related regression tests.

No P1 changes are included.
