# P0 changes

1. Deep replay test: `sink.finalize('STOP', ...)` -> `sink.finalize('PASS', ...)`.
2. Launcher: near-command typo detection before plain LLM fallback; `statuz` is rejected, `hello` remains plain text.
3. Launcher tests for typo/free-text separation.
4. Latest-LiDAR backend acceptance: relative motion survives when global pose is not publishable.
5. L6: global NAVIGATE requires `map_to_odom`; missing transform -> `INVALIDATED / GLOBAL_TRANSFORM_MISSING`.
6. Dual-frame regression: missing global transform produces downstream zero motion, while local NAVIGATE remains valid.
