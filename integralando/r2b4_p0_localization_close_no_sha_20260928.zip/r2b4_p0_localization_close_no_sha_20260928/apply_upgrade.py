#!/usr/bin/env python3
from __future__ import annotations

import argparse
import py_compile
import shutil
import sys
from datetime import datetime
from pathlib import Path

UPGRADE_ID = "R2B4_P0_DUAL_FRAME_CLOSE_NO_SHA_20260928"

# Intentionally NO commit-SHA/blob-SHA/full-file hash checks.
# Patches are anchored only to the concrete code fragment they change.
# Each patch is idempotent: already-fixed code is skipped.
PATCHES: dict[str, list[tuple[str, str]]] = {
    "tests/deep/test_v3_lidar_world_replay.py": [
        (
            "    path = sink.finalize('STOP', tmp_path/'capture.json', initial_state_checkpoint=encode_value(checkpoint))\n",
            "    path = sink.finalize('PASS', tmp_path/'capture.json', initial_state_checkpoint=encode_value(checkpoint))\n",
        ),
    ],
    "v3/launcher_cli.py": [
        (
            '''def _unknown_command(command: str) -> int:\n    known = {item["name"] for item in _robot_catalog()} | set(interface_cli.ALIASES)\n    known |= set(host_cli.COMMANDS) | {"er2", "voice", "wake", "help", "commands"}\n    matches = difflib.get_close_matches(command, sorted(known), n=3, cutoff=0.6)\n''',
            '''def _command_names() -> set[str]:\n    known = {item["name"] for item in _robot_catalog()} | set(interface_cli.ALIASES)\n    known |= set(host_cli.COMMANDS) | {"er2", "voice", "wake", "help", "commands"}\n    return known\n\n\ndef _looks_like_command_typo(command: str) -> bool:\n    # Keep short/free text such as `r "hello"` on the plain-LLM path, while\n    # obvious near-misses such as `statuz` fail locally instead of reaching Gemini.\n    return bool(\n        difflib.get_close_matches(\n            command, sorted(_command_names()), n=1, cutoff=0.8\n        )\n    )\n\n\ndef _unknown_command(command: str) -> int:\n    matches = difflib.get_close_matches(\n        command, sorted(_command_names()), n=3, cutoff=0.6\n    )\n''',
        ),
        (
            '''        if not args[0].startswith("-"):\n            known = {item["name"] for item in _robot_catalog()} | set(interface_cli.ALIASES)\n            if args[0] not in known:\n                return _plain_prompt(args, root)\n''',
            '''        if not args[0].startswith("-"):\n            known = {item["name"] for item in _robot_catalog()} | set(interface_cli.ALIASES)\n            if args[0] not in known:\n                if _looks_like_command_typo(args[0]):\n                    return _unknown_command(args[0])\n                return _plain_prompt(args, root)\n''',
        ),
    ],
    "tests/feature/test_plain_llm_launcher.py": [
        (
            '''    assert launcher_cli.main(["s"]) == 31\n''',
            '''    assert launcher_cli.main(["s"]) == 31\n\n\ndef test_launcher_near_command_typo_does_not_route_to_plain(monkeypatch, tmp_path, capsys):\n    from v3 import launcher_cli, runtime_performance\n\n    monkeypatch.setattr(launcher_cli, "project_root", lambda: tmp_path)\n    monkeypatch.setattr(runtime_performance, "apply_host_affinity", lambda *_args, **_kwargs: None)\n    monkeypatch.setattr(launcher_cli, "_robot_catalog", lambda: [{"name": "status"}])\n    monkeypatch.setattr(launcher_cli.interface_cli, "ALIASES", {})\n    monkeypatch.setattr(\n        launcher_cli,\n        "_plain_prompt",\n        lambda *_args, **_kwargs: (_ for _ in ()).throw(AssertionError("typo must not reach plain LLM")),\n    )\n\n    assert launcher_cli.main(["statuz"]) == 2\n    captured = capsys.readouterr()\n    assert captured.out == ""\n    assert "r status" in captured.err\n\n\ndef test_launcher_distant_single_word_stays_plain_llm(monkeypatch, tmp_path):\n    from v3 import launcher_cli, runtime_performance\n\n    called = {}\n    monkeypatch.setattr(launcher_cli, "project_root", lambda: tmp_path)\n    monkeypatch.setattr(runtime_performance, "apply_host_affinity", lambda *_args, **_kwargs: None)\n    monkeypatch.setattr(launcher_cli, "_robot_catalog", lambda: [{"name": "status"}])\n    monkeypatch.setattr(launcher_cli.interface_cli, "ALIASES", {})\n\n    def fake_plain(argv, root):\n        called["argv"] = list(argv)\n        called["root"] = root\n        return 37\n\n    monkeypatch.setattr(launcher_cli, "_plain_prompt", fake_plain)\n\n    assert launcher_cli.main(["hello"]) == 37\n    assert called == {"argv": ["hello"], "root": tmp_path}\n''',
        ),
    ],
    "tests/feature/test_v3_latest_lidar_backend.py": [
        (
            '''    with pytest.raises(ValueError, match='cannot exceed'):\n        LatestLidarBackendConfig(20000000, maximum_future_skew_ns=20000001)\n''',
            '''    with pytest.raises(ValueError, match='cannot exceed'):\n        LatestLidarBackendConfig(20000000, maximum_future_skew_ns=20000001)\n\n\ndef test_relative_motion_survives_when_global_pose_is_not_publishable():\n    relative = {\n        'start_ns': 830000000,\n        'dx_m': 0.02,\n        'dy_m': -0.003,\n        'dyaw_rad': 0.01,\n        'rmse_m': 0.002,\n        'observability': 0.9,\n    }\n    port = Port(\n        _result(summary=_summary(tracking_ready=False, relative_motion=relative)),\n        _status(),\n    )\n    source = NativeLidarSource(_backend(port), NativeLidarConfig('lidar', 0.3, 250000000))\n    snapshot = source.read(TickContext(7, 1000000000))\n    kinds = tuple(sample.kind for sample in snapshot.samples)\n\n    assert 'lidar_safety_clearance' in kinds\n    assert 'lidar_local_points' in kinds\n    assert 'lidar_relative_motion' in kinds\n    assert 'lidar_pose' not in kinds\n\n    sample = next(item for item in snapshot.samples if item.kind == 'lidar_relative_motion')\n    values = {field.key: field.value for field in sample.values}\n    assert values == relative\n''',
        ),
    ],
    "v3/layers/l6_navigation.py": [
        (
            '''        if mission.target_frame_id != LOCAL_FRAME_ID and estimate.map_to_odom is not None:\n            target = Waypoint(*estimate.map_to_odom.inverse().apply(target.x_m, target.y_m, target.yaw_rad))\n''',
            '''        if mission.target_frame_id != LOCAL_FRAME_ID:\n            if estimate.map_to_odom is None:\n                self._clear_trajectory_plan()\n                return self._inactive(\n                    mission,\n                    NavigationStatus.INVALIDATED,\n                    "GLOBAL_TRANSFORM_MISSING",\n                )\n            target = Waypoint(*estimate.map_to_odom.inverse().apply(target.x_m, target.y_m, target.yaw_rad))\n''',
        ),
    ],
    "tests/feature/test_v3_dual_frame_localization.py": [
        (
            '''    assert recovered.local_goal.x_m == pytest.approx(target[0])\n    assert recovered.local_goal.y_m == pytest.approx(target[1])\n\n\ndef test_localization_stale_imu_slip_and_bad_producer_fail_closed():\n''',
            '''    assert recovered.local_goal.x_m == pytest.approx(target[0])\n    assert recovered.local_goal.y_m == pytest.approx(target[1])\n\n    # A global NAVIGATE target must never fall through as local coordinates when\n    # the map->odom transform is unavailable. Local-frame navigation remains valid.\n    missing_transform = replace(\n        fixed.in_local_frame(),\n        local_pose=None,\n        global_pose=None,\n        map_to_odom=None,\n    )\n    blocked = nav.evaluate(mission, missing_transform, fixed_world)\n    assert blocked.status is NavigationStatus.INVALIDATED\n    assert blocked.reason == "GLOBAL_TRANSFORM_MISSING"\n    blocked_motion = realizer.evaluate(selector.evaluate(blocked), missing_transform, fixed_world)\n    assert blocked_motion.requested_v_mps == blocked_motion.requested_omega_rad_s == 0.0\n\n    local_manager, local_nav, _, _, _ = layers(config)\n    local_mission = local_manager.evaluate(CommandRequest(\n        f.context, "local-no-transform", CommandMode.NAVIGATE,\n        (DataField("x_m", 1.0), DataField("y_m", 0.0), DataField("frame_id", LOCAL_FRAME_ID)), 351))\n    local_plan = local_nav.evaluate(local_mission, missing_transform, fixed_world)\n    assert local_plan.status is NavigationStatus.ACTIVE\n\n\ndef test_localization_stale_imu_slip_and_bad_producer_fail_closed():\n''',
        ),
    ],
}


def _plan_file(path: Path, edits: list[tuple[str, str]]) -> tuple[str | None, list[str]]:
    if not path.is_file():
        raise RuntimeError(f"missing file: {path}")
    text = path.read_text(encoding="utf-8")
    original = text
    states: list[str] = []

    for index, (old, new) in enumerate(edits, 1):
        old_count = text.count(old)
        new_count = text.count(new)

        # New block may contain a short old anchor as a substring; if the entire
        # replacement exists, the edit is already applied and must not duplicate.
        if new_count >= 1:
            states.append(f"edit {index}: already applied")
            continue
        if old_count == 1:
            text = text.replace(old, new, 1)
            states.append(f"edit {index}: patch")
            continue
        raise RuntimeError(
            f"anchor mismatch: edit {index}: old={old_count}, fixed={new_count}"
        )

    return (None if text == original else text), states


def _preflight(root: Path) -> tuple[dict[str, str], dict[str, list[str]]]:
    if not (root / "v3").is_dir() or not (root / "pytest.ini").is_file():
        raise RuntimeError(f"not an R2B4 repository root: {root}")

    staged: dict[str, str] = {}
    report: dict[str, list[str]] = {}
    errors: list[str] = []
    for relative, edits in PATCHES.items():
        try:
            text, states = _plan_file(root / relative, edits)
            report[relative] = states
            if text is not None:
                staged[relative] = text
        except Exception as exc:
            errors.append(f"{relative}: {exc}")

    if errors:
        raise RuntimeError("preflight failed:\n  - " + "\n  - ".join(errors))
    return staged, report


def apply(root: Path) -> tuple[Path | None, dict[str, list[str]]]:
    staged, report = _preflight(root)
    if not staged:
        return None, report

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_root = root / ".upgrade_backups" / f"p0_dual_frame_close_no_sha_{stamp}"

    for relative in staged:
        source = root / relative
        backup = backup_root / relative
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, backup)

    written: list[str] = []
    try:
        for relative, text in staged.items():
            path = root / relative
            temp = path.with_name(path.name + ".upgrade_tmp")
            temp.write_text(text, encoding="utf-8")
            temp.replace(path)
            written.append(relative)

        for relative in staged:
            if relative.endswith(".py"):
                py_compile.compile(str(root / relative), doraise=True)
    except Exception:
        for relative in written:
            backup = backup_root / relative
            if backup.exists():
                shutil.copy2(backup, root / relative)
        raise

    return backup_root, report


def _print_report(report: dict[str, list[str]]) -> None:
    for relative, states in report.items():
        print(relative)
        for state in states:
            print(f"  - {state}")


def main() -> int:
    parser = argparse.ArgumentParser(description=f"Apply {UPGRADE_ID}")
    parser.add_argument("root", nargs="?", default=".", help="R2B4 repository root")
    parser.add_argument("--check", action="store_true", help="anchor-only preflight; no write")
    args = parser.parse_args()
    root = Path(args.root).expanduser().resolve()

    try:
        if args.check:
            staged, report = _preflight(root)
            print(f"{UPGRADE_ID}: PRECHECK PASS")
            _print_report(report)
            print(f"files_to_change={len(staged)}")
            return 0

        backup, report = apply(root)
    except Exception as exc:
        print(f"{UPGRADE_ID}: FAIL: {exc}", file=sys.stderr)
        return 2

    if backup is None:
        print(f"{UPGRADE_ID}: ALREADY_APPLIED")
    else:
        print(f"{UPGRADE_ID}: APPLIED")
        print(f"backup={backup}")
    _print_report(report)
    print("Next: run verify.sh --full.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
