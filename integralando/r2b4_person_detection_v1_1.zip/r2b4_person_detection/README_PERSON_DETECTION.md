# R2B4 person detection — development package v1.1

Base repo inspected: `Francigofree/r2b4`, main at commit `2a71a254d1de003d6d5e388a861fd9e825e82260`.

## Included

- `v3/adapters/person_detection.py`
  - immutable person boxes/detections/results;
  - latest-only asynchronous worker;
  - no image queue buildup;
  - detector failure stays local to the detector capability.
- `v3/adapters/litert_person_detector.py`
  - LiteRT/TFLite SSD/EfficientDet-style backend;
  - RGB888 stride-aware input handling;
  - configurable person class, threshold, max results and threads;
  - `ai-edge-litert` is imported only when this backend is instantiated.
- `v3/adapters/live_person_detection.py`
  - non-critical V3 auxiliary source;
  - publishes only small semantic data (`person_count`, primary box, confidence, timing), never raw image bytes.
- `tools/v3_person_detection_test.py`
  - bounded live hardware test;
  - uses the existing native Camera Module 3 owner;
  - refuses parallel ownership while resident runtime is alive.
- `tests/test_v3_person_detection.py`
  - worker lineage, best detection, backend output filtering and failure isolation tests.

## Install files

From the repo root, extract/copy this package so the paths merge into the existing tree. These are new files only.

## LiteRT runtime

The core R2B4 requirements are intentionally unchanged. Person inference is optional and loads `ai-edge-litert` lazily.

Current Raspberry Pi Picamera2 examples use:

```bash
pip3 install ai-edge-litert
```

Use the same system Python that runs R2B4. Do not install a second camera stack.

## Model

The default backend expects a standard TFLite Detection_PostProcess-style EfficientDet/SSD model at:

```text
models/efficientdet_lite0.tflite
```

The TensorFlow Raspberry Pi example currently publishes EfficientDet-Lite0 here:

```bash
mkdir -p models
curl -L 'https://storage.googleapis.com/download.tensorflow.org/models/tflite/task_library/object_detection/rpi/lite-model_efficientdet_lite0_detection_metadata_1.tflite' \
  -o models/efficientdet_lite0.tflite
```

The default assumes COCO person class id `0`. If another TFLite model uses background class 0 and person class 1, run with `--person-class-id 1`.

## Targeted tests

```bash
PYTHONPATH=. pytest -q tests/test_v3_person_detection.py
```

Development-package result: `4 passed`.

## First live person-detection test

Stop resident runtime first because this standalone validation owns the camera deliberately:

```bash
./r2b4 stop
python3 tools/v3_person_detection_test.py --seconds 20
```

The tool emits one JSON line per inference result and a final summary with result rate, number of frames containing a person, best confidence and any detector error.

## Deliberately not included yet

This package does **not** make the robot follow a person and does not create motor authority. It also does not yet instantiate the detector automatically inside the resident hardware owner. The next safe step after the Pi 5 live inference test is to wire `NativePersonDetector` + `NativePersonDetectionSource` into the existing `auxiliary_sources` path, then verify resident runtime timing while moving.

No V3 architecture document change is required for this stage: it fits the existing immutable edge snapshot and passive/non-critical capability rules.

## v1.1 corrections

- Picamera2 `RGB888` buffer channel order is converted to true RGB before LiteRT inference.
- A detector stop timeout retains the live worker reference, preventing a second concurrent inference worker from being started.
- The package still intentionally does not wire person detection into resident runtime; first validate standalone live inference.
