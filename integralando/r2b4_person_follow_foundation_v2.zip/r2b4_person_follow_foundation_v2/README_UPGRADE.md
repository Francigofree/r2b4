# R2B4 Person Detection → RoomCruise Photo Evidence upgrade

Baseline analysed: `Francigofree/r2b4` main at `e0c1183b2cb67d99d1dafc4f980ebb3b91675746`.

This package performs the next bounded step toward person-follow behaviour. It does **not** give the detector motor authority and does **not** implement FOLLOW steering yet.

## Resulting data path

```text
single NativePicamera2Camera owner
        │
        ├─ lores RGB888 → NativePersonDetector → PERSON_DETECTOR_FRONT
        │                                      ↓
        │                              L0 → L1 → L2 admission
        │                                      ↓
        │                         completed person_detection observation
        │                                      │
        └─ main YUV420 ───────────── JPEG request ← L5 ACTIVE EXPLORE
                                               │
                                               └─ pic/person_*.jpg

EXPLORE/RoomCruise motion itself remains:
CommandGateway → L5 → L6 → L7 → L8 → L9 → L10 → L11 → L12
```

The photo-evidence edge is passive. It observes already completed L2 + L5 values. It cannot issue commands, modify mission/navigation state, or write motors.

### Photo policy

- only `ACTIVE + EXPLORE` (therefore RoomCruise), never TELEOP/STOP;
- 3 consecutive **new L2-admitted** person detections before requesting a photo;
- one photo per continuous person-presence episode;
- rearm after 5 new person-free detector results;
- at least 5 seconds between accepted photo requests;
- JPEG comes from the already-running `main` 1280x720 camera stream;
- only one camera photo request may be pending; no unbounded queue;
- JPEG failure is non-critical and must not stop camera acquisition or motor runtime;
- detector/camera remain non-critical to normal TELEOP/EXPLORE motor safety; encoder/IMU/LiDAR remain the production critical set.

## Files changed by the applicator

- `v3/adapters/person_detection.py` — makes `stop()` explicit in the owned person-detection port contract.
- `v3/adapters/picamera2_camera.py` — bounded JPEG request on the existing Picamera2 session; no second camera owner.
- `v3/adapters/person_photo_evidence.py` — new passive L2+L5 evidence policy.
- `v3/composition/native_sensor_inputs.py` — closes detector source/owner lifecycle and publishes it as an auxiliary L0 source.
- `v3_bounded_config.py` — parses top-level `person_detection` configuration separately from strict camera config.
- `v3_hardware_runtime.py` — creates the LiteRT detector from the existing camera frame port, isolates detector startup failure, and observes completed L2/L5 ticks for photo evidence.
- `conf/hardver.json` — enables detector and RoomCruise photo evidence.
- `requirements.txt` — records the Pi-proven LiteRT/NumPy/SciPy compatibility set.
- `.gitignore` — ignores local TFLite models and `pic/` evidence.
- `tests/test_v3_person_detection_runtime_integration.py` — new integration/boundary tests.

`v3/import_guard.py` is intentionally **not modified** by this package: current main already contains the narrow LiteRT edge permission and the L12 shared device-health-policy permission.

No V3 architecture-document change is required for this slice. The current contract already permits one physical sensor to expose multiple semantic capabilities, asynchronous immutable/timestamped processing, and passive completed-value capture edges.

## Apply safely

Do not use `gitre.py` or `git add -A` until the resulting diff has been inspected.

```bash
cd ~/project_r2b4

git status --short

rm -rf /tmp/r2b4-person-follow-v2
mkdir -p /tmp/r2b4-person-follow-v2
unzip -q /PATH/TO/r2b4_person_follow_foundation_v2.zip -d /tmp/r2b4-person-follow-v2

python3 /tmp/r2b4-person-follow-v2/r2b4_person_follow_foundation_v2/apply_upgrade.py \
  --root ~/project_r2b4 --check
```

Expected:

```text
CHECK PASS: 10 files are applicable
```

Then apply:

```bash
python3 /tmp/r2b4-person-follow-v2/r2b4_person_follow_foundation_v2/apply_upgrade.py \
  --root ~/project_r2b4
```

The applicator does not commit or push. It validates every source anchor and all generated Python before the first write, and attempts rollback if a write fails.

## Dependency sanity check

Do **not** reinstall LiteRT if the working live detector already passes. Verify the current environment instead:

```bash
python3 - <<'PY'
import numpy, scipy
from ai_edge_litert.interpreter import Interpreter
from picamera2 import Picamera2
print("numpy", numpy.__version__, numpy.__file__)
print("scipy", scipy.__version__, scipy.__file__)
print("LiteRT + Picamera2: OK")
PY
```

The live-proven Pi state was NumPy `1.24.2`, SciPy `1.10.1`, `ai-edge-litert==2.2.0`.

## Static / regression validation

```bash
cd ~/project_r2b4

PYTHONPATH=. pytest -q \
  tests/test_v3_person_detection.py \
  tests/test_v3_person_detection_runtime_integration.py \
  tests/test_v3_camera_foundation.py \
  tests/test_v3_native_sensor_inputs.py \
  tests/test_v3_hardware_runtime.py \
  tests/test_v3_bounded_runtime_config.py \
  tests/test_v3_architecture_boundaries.py

python3 -m v3.import_guard

python3 - <<'PY'
from v3_process_runtime import load_resident_runtime_config
c = load_resident_runtime_config()
s = c.sensor_inputs
print("backend:", s.person_detection_backend)
print("source:", s.inputs.person_detection_source)
print("photo:", s.person_photo_evidence)
PY

git diff -- \
  v3/adapters/person_detection.py \
  v3/adapters/picamera2_camera.py \
  v3/adapters/person_photo_evidence.py \
  v3/composition/native_sensor_inputs.py \
  v3_bounded_config.py \
  v3_hardware_runtime.py \
  conf/hardver.json requirements.txt .gitignore \
  tests/test_v3_person_detection_runtime_integration.py
```

Do not proceed to physical motion unless these are clean.

## Live acceptance test: RoomCruise + person photo

This test deliberately does **not** make Alba follow the person yet. RoomCruise continues its normal EXPLORE behaviour while person detection runs passively.

Restart the resident runtime so the new code is loaded:

```bash
cd ~/project_r2b4
./r2b4 stop
./r2b4 runtime start
```

Check that no new photo is created merely while IDLE. Then run the physical test:

```bash
./r2b4 roomcruise c full
```

Test procedure:

1. Start with nobody in front of the camera for ~2 seconds.
2. Enter the camera view at roughly 1–3 m while RoomCruise is moving.
3. Stay visible for at least ~0.5 s. Three detector results are required.
4. A file named like `pic/person_YYYYMMDD_HHMMSS_mmm_det000123_frame000456.jpg` should appear.
5. Stay continuously visible: another image should **not** be generated continuously.
6. Leave the view long enough for at least 5 detector results, wait at least 5 s, then re-enter. One new photo may be generated for the new presence episode.
7. Stop with the normal launcher/Ctrl+C path.

Afterward:

```bash
find pic -maxdepth 1 -type f -name 'person_*.jpg' -printf '%TY-%Tm-%Td %TH:%TM:%TS %s %p\n' | sort | tail -20
./r2b4 runtime status
```

Acceptance criteria:

- RoomCruise still reaches its normal ACTIVE/ALLOW path and moves normally.
- Person detector activity does not create a critical-device FAULT.
- At least one non-empty JPEG appears only after stable person detection during ACTIVE EXPLORE.
- Continuous visibility does not create an image flood.
- STOP/shutdown completes normally; no detector/camera thread hang.
- The MCAP for the run remains the authority for L0-L12 behaviour; photo files are supplementary evidence only.

## What remains for actual FOLLOW

After this slice passes live, the next production change should **not** wire detector output directly to motion. The next slice is:

```text
L2 admitted person_detection
        ↓
L4 person-target state (freshness + short dropout tolerance + target continuity)
        ↓
L5 explicit FOLLOW mission semantics
        ↓
L6 target-relative navigation objective using the same planner/safety path
        ↓
L7 → L8 → L9 → L10 → L11 → L12
```

That next slice needs explicit target-lost STOP/HOLD behaviour, camera bearing calibration and an initial range strategy. LiDAR collision/safety authority remains independent and unchanged.
