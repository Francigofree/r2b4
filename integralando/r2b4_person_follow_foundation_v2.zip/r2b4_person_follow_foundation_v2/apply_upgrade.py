#!/usr/bin/env python3
"""Apply the R2B4 resident person-detection + passive photo-evidence upgrade.

Baseline analysed: Francigofree/r2b4 main @ e0c1183b2cb67d99d1dafc4f980ebb3b91675746.
The script is intentionally source-first and transactional: every expected source
anchor is verified in memory before any file is written.  Unrelated working-tree
changes are not touched, and no commit/push is performed.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

BASELINE = "e0c1183b2cb67d99d1dafc4f980ebb3b91675746"
PACKAGE_ROOT = Path(__file__).resolve().parent


class UpgradeError(RuntimeError):
    pass


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise UpgradeError(f"{label}: expected source anchor exactly once, found {count}")
    return text.replace(old, new, 1)


def read_text(root: Path, relative: str) -> str:
    path = root / relative
    if path.is_symlink() or not path.is_file():
        raise UpgradeError(f"missing regular source file: {relative}")
    return path.read_text(encoding="utf-8")


def atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.upgrade.", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise




def patch_person_detection(text: str) -> str:
    return replace_once(
        text,
        '''class PersonDetectionPort(Protocol):
    def get_detection_snapshot(self) -> PersonDetectionSnapshot | None: ...

    def get_detection_status(self) -> PersonDetectionRuntimeStatus: ...

    def wait_for_new_detection(
        self, after_sequence: int = 0, timeout_s: float = 1.0
    ) -> PersonDetectionSnapshot | None: ...
''',
        '''class PersonDetectionPort(Protocol):
    def get_detection_snapshot(self) -> PersonDetectionSnapshot | None: ...

    def get_detection_status(self) -> PersonDetectionRuntimeStatus: ...

    def wait_for_new_detection(
        self, after_sequence: int = 0, timeout_s: float = 1.0
    ) -> PersonDetectionSnapshot | None: ...

    def stop(self) -> None: ...
''',
        "person detection owned-port stop contract",
    )


def patch_picamera2_camera(text: str) -> str:
    text = replace_once(
        text,
        '''import math\nimport threading\nimport time\nfrom collections.abc import Callable, Mapping\nfrom dataclasses import dataclass\nfrom typing import Protocol\n''',
        '''import math\nimport threading\nimport time\nfrom collections.abc import Callable, Mapping\nfrom dataclasses import dataclass\nfrom pathlib import Path\nfrom typing import Protocol\n''',
        "picamera imports",
    )
    text = replace_once(
        text,
        '''class Picamera2Request(Protocol):\n    def get_metadata(self) -> Mapping[str, object]: ...\n\n    def make_buffer(self, stream_name: str) -> object: ...\n\n    def release(self) -> None: ...\n''',
        '''class Picamera2Request(Protocol):\n    def get_metadata(self) -> Mapping[str, object]: ...\n\n    def make_buffer(self, stream_name: str) -> object: ...\n\n    def save(\n        self, stream_name: str, output: str, *, format: str | None = None\n    ) -> object: ...\n\n    def release(self) -> None: ...\n''',
        "picamera request save port",
    )
    text = replace_once(
        text,
        '''@dataclass(frozen=True, slots=True)\nclass CameraEdgeSnapshot:\n    """One coherent read of camera status and its corresponding latest frame."""\n\n    status: CameraRuntimeStatus\n    frame: CameraFrameSnapshot | None\n''',
        '''@dataclass(frozen=True, slots=True)\nclass CameraPhotoStatus:\n    """Non-critical JPEG request status from the existing camera owner."""\n\n    pending: bool\n    saved_count: int\n    last_output: str | None\n    last_error: str | None\n\n\n@dataclass(frozen=True, slots=True)\nclass CameraEdgeSnapshot:\n    """One coherent read of camera status and its corresponding latest frame."""\n\n    status: CameraRuntimeStatus\n    frame: CameraFrameSnapshot | None\n''',
        "camera photo status contract",
    )
    text = replace_once(
        text,
        '''        "_picamera",\n        "_running",\n        "_sequence",\n        "_stop_event",\n        "_thread",\n        "_timestamp_mapper",\n''',
        '''        "_picamera",\n        "_running",\n        "_sequence",\n        "_stop_event",\n        "_thread",\n        "_timestamp_mapper",\n        "_pending_photo",\n        "_photo_saved_count",\n        "_photo_last_output",\n        "_photo_last_error",\n''',
        "camera photo slots",
    )
    text = replace_once(
        text,
        '''        self._last_error: str | None = None\n        self._model: str | None = None\n''',
        '''        self._last_error: str | None = None\n        self._model: str | None = None\n        self._pending_photo: tuple[str, str] | None = None\n        self._photo_saved_count = 0\n        self._photo_last_output: str | None = None\n        self._photo_last_error: str | None = None\n''',
        "camera photo state init",
    )
    text = replace_once(
        text,
        '''            self._last_error = None\n            self._model = None\n            self._stop_event.clear()\n''',
        '''            self._last_error = None\n            self._model = None\n            self._pending_photo = None\n            self._photo_saved_count = 0\n            self._photo_last_output = None\n            self._photo_last_error = None\n            self._stop_event.clear()\n''',
        "camera photo state reset",
    )
    text = replace_once(
        text,
        '''            self._running = False\n            self._stop_event.set()\n            self._frame_condition.notify_all()\n''',
        '''            self._running = False\n            self._stop_event.set()\n            self._pending_photo = None\n            self._frame_condition.notify_all()\n''',
        "camera stop clears photo request",
    )
    text = replace_once(
        text,
        '''    def get_runtime_status(self) -> CameraRuntimeStatus:\n        return self.get_edge_snapshot().status\n\n    def wait_for_new_frame(\n''',
        '''    def get_runtime_status(self) -> CameraRuntimeStatus:\n        return self.get_edge_snapshot().status\n\n    def request_jpeg(\n        self,\n        output: str | Path,\n        *,\n        stream_name: str = "lores",\n    ) -> bool:\n        """Queue at most one JPEG on the already-owned Picamera2 session.\n\n        The request is non-blocking for the caller.  Encoding/file I/O happens\n        on the camera acquisition thread while the corresponding Picamera2\n        request is still valid.  Failure is isolated from camera acquisition\n        health and is reported only through ``get_photo_status``.\n        """\n\n        path = Path(output).expanduser()\n        if path.suffix.lower() not in {".jpg", ".jpeg"}:\n            raise ValueError("camera photo output must use .jpg or .jpeg")\n        if stream_name not in {"main", "lores"}:\n            raise ValueError("camera photo stream_name must be 'main' or 'lores'")\n        with self._frame_condition:\n            if not self._running or self._pending_photo is not None:\n                return False\n            self._pending_photo = (str(path), stream_name)\n            self._photo_last_error = None\n            self._frame_condition.notify_all()\n            return True\n\n    def get_photo_status(self) -> CameraPhotoStatus:\n        with self._lock:\n            return CameraPhotoStatus(\n                pending=self._pending_photo is not None,\n                saved_count=self._photo_saved_count,\n                last_output=self._photo_last_output,\n                last_error=self._photo_last_error,\n            )\n\n    def wait_for_new_frame(\n''',
        "camera photo request API",
    )
    text = replace_once(
        text,
        '''                snapshot = self._snapshot_from_request(request, geometry)\n                with self._frame_condition:\n                    self._latest = snapshot\n                    self._last_error = None\n                    self._frame_condition.notify_all()\n''',
        '''                snapshot = self._snapshot_from_request(request, geometry)\n                with self._frame_condition:\n                    pending_photo = self._pending_photo\n                    self._pending_photo = None\n                    self._latest = snapshot\n                    self._last_error = None\n                    self._frame_condition.notify_all()\n                if pending_photo is not None:\n                    output, stream_name = pending_photo\n                    try:\n                        saver = getattr(request, "save", None)\n                        if not callable(saver):\n                            raise RuntimeError("Picamera2 request.save is unavailable")\n                        saver(stream_name, output, format="jpeg")\n                        with self._frame_condition:\n                            self._photo_saved_count += 1\n                            self._photo_last_output = output\n                            self._photo_last_error = None\n                            self._frame_condition.notify_all()\n                    except Exception as photo_exc:\n                        # Photo evidence must never terminate camera acquisition.\n                        with self._frame_condition:\n                            self._photo_last_error = (\n                                f"{type(photo_exc).__name__}:{photo_exc}"\n                            )\n                            self._frame_condition.notify_all()\n''',
        "camera worker photo save",
    )
    text = replace_once(
        text,
        '''    "CameraFramePort",\n    "CameraFrameSnapshot",\n    "CameraRuntimeStatus",\n''',
        '''    "CameraFramePort",\n    "CameraFrameSnapshot",\n    "CameraPhotoStatus",\n    "CameraRuntimeStatus",\n''',
        "camera exports",
    )
    return text


def patch_native_sensor_inputs(text: str) -> str:
    text = replace_once(
        text,
        '''from v3.adapters.live_lidar import NativeLidarConfig, NativeLidarSource\nfrom v3.adapters.live_camera import CameraFramePort, NativeCameraConfig, NativeCameraSource\nfrom v3.adapters.live_inputs import LiveDeviceSource\nfrom v3.adapters.picamera2_camera import Picamera2CameraConfig\n''',
        '''from v3.adapters.live_lidar import NativeLidarConfig, NativeLidarSource\nfrom v3.adapters.live_camera import CameraFramePort, NativeCameraConfig, NativeCameraSource\nfrom v3.adapters.live_inputs import LiveDeviceSource\nfrom v3.adapters.live_person_detection import (\n    NativePersonDetectionConfig,\n    NativePersonDetectionSource,\n)\nfrom v3.adapters.litert_person_detector import LiteRtPersonDetectorConfig\nfrom v3.adapters.person_detection import PersonDetectionPort\nfrom v3.adapters.person_photo_evidence import PersonPhotoEvidenceConfig\nfrom v3.adapters.picamera2_camera import Picamera2CameraConfig\n''',
        "native sensor person imports",
    )
    text = replace_once(
        text,
        '''    lidar_backend: LatestLidarBackendConfig\n    lidar_source: NativeLidarConfig\n    camera_source: NativeCameraConfig | None = None\n''',
        '''    lidar_backend: LatestLidarBackendConfig\n    lidar_source: NativeLidarConfig\n    camera_source: NativeCameraConfig | None = None\n    person_detection_source: NativePersonDetectionConfig | None = None\n''',
        "native input person source config",
    )
    text = replace_once(
        text,
        '''        if self.camera_source is not None and not isinstance(\n            self.camera_source, NativeCameraConfig\n        ):\n            raise TypeError("camera_source must be NativeCameraConfig or None")\n        device_ids = (\n''',
        '''        if self.camera_source is not None and not isinstance(\n            self.camera_source, NativeCameraConfig\n        ):\n            raise TypeError("camera_source must be NativeCameraConfig or None")\n        if self.person_detection_source is not None and not isinstance(\n            self.person_detection_source, NativePersonDetectionConfig\n        ):\n            raise TypeError(\n                "person_detection_source must be NativePersonDetectionConfig or None"\n            )\n        device_ids = (\n''',
        "native input person source type",
    )
    text = replace_once(
        text,
        '''        if self.camera_source is not None:\n            device_ids += (self.camera_source.device_id,)\n        if len(set(device_ids)) != len(device_ids):\n''',
        '''        if self.camera_source is not None:\n            device_ids += (self.camera_source.device_id,)\n        if self.person_detection_source is not None:\n            device_ids += (self.person_detection_source.device_id,)\n        if len(set(device_ids)) != len(device_ids):\n''',
        "native input unique person device id",
    )
    text = replace_once(
        text,
        '''class NativeSensorHardwareConfig:\n    """Closed native device and typed-source configuration for one owner."""\n\n    imu_device: NativeBno055DeviceConfig\n    inputs: NativeSensorInputConfig\n    lidar_danger_zone_m: float\n    camera_device: Picamera2CameraConfig | None = None\n''',
        '''class NativeSensorHardwareConfig:\n    """Closed native device and typed-source configuration for one owner."""\n\n    imu_device: NativeBno055DeviceConfig\n    inputs: NativeSensorInputConfig\n    lidar_danger_zone_m: float\n    camera_device: Picamera2CameraConfig | None = None\n    person_detection_backend: LiteRtPersonDetectorConfig | None = None\n    person_photo_evidence: PersonPhotoEvidenceConfig | None = None\n''',
        "native hardware person config fields",
    )
    text = replace_once(
        text,
        '''        if (self.camera_device is None) != (self.inputs.camera_source is None):\n            raise ValueError("camera device and source configs must be enabled together")\n        if (\n''',
        '''        if (self.camera_device is None) != (self.inputs.camera_source is None):\n            raise ValueError("camera device and source configs must be enabled together")\n        if self.person_detection_backend is not None and not isinstance(\n            self.person_detection_backend, LiteRtPersonDetectorConfig\n        ):\n            raise TypeError(\n                "person_detection_backend must be LiteRtPersonDetectorConfig or None"\n            )\n        if self.person_photo_evidence is not None and not isinstance(\n            self.person_photo_evidence, PersonPhotoEvidenceConfig\n        ):\n            raise TypeError(\n                "person_photo_evidence must be PersonPhotoEvidenceConfig or None"\n            )\n        if (self.person_detection_backend is None) != (\n            self.inputs.person_detection_source is None\n        ):\n            raise ValueError(\n                "person detector backend and source configs must be enabled together"\n            )\n        if self.person_detection_backend is not None and self.camera_device is None:\n            raise ValueError("person detection requires the native camera capability")\n        if self.person_photo_evidence is not None and self.person_detection_backend is None:\n            raise ValueError("person photo evidence requires person detection")\n        if (\n''',
        "native hardware person config validation",
    )
    text = replace_once(
        text,
        '''        "_camera_port",\n        "_camera_source",\n        "_closed",\n''',
        '''        "_camera_port",\n        "_camera_source",\n        "_person_detection_port",\n        "_person_detection_source",\n        "_closed",\n''',
        "native input owner person slots",
    )
    text = replace_once(
        text,
        '''        config: NativeSensorInputConfig,\n        *,\n        camera_port: CameraFramePort | None = None,\n    ) -> None:\n''',
        '''        config: NativeSensorInputConfig,\n        *,\n        camera_port: CameraFramePort | None = None,\n        person_detection_port: PersonDetectionPort | None = None,\n    ) -> None:\n''',
        "native input owner person arg",
    )
    text = replace_once(
        text,
        '''        if camera_port is not None and not callable(getattr(camera_port, "stop", None)):\n            raise TypeError("camera port owner must provide stop")\n\n        try:\n''',
        '''        if camera_port is not None and not callable(getattr(camera_port, "stop", None)):\n            raise TypeError("camera port owner must provide stop")\n        if (config.person_detection_source is None) != (person_detection_port is None):\n            raise ValueError(\n                "person detection port and source config must be enabled together"\n            )\n        if person_detection_port is not None and not callable(\n            getattr(person_detection_port, "stop", None)\n        ):\n            raise TypeError("person detection port owner must provide stop")\n\n        try:\n''',
        "native input owner person validation",
    )
    text = replace_once(
        text,
        '''            camera_source = (\n                NativeCameraSource(camera_port, config.camera_source)\n                if camera_port is not None and config.camera_source is not None\n                else None\n            )\n        except Exception:\n''',
        '''            camera_source = (\n                NativeCameraSource(camera_port, config.camera_source)\n                if camera_port is not None and config.camera_source is not None\n                else None\n            )\n            person_detection_source = (\n                NativePersonDetectionSource(\n                    person_detection_port, config.person_detection_source\n                )\n                if person_detection_port is not None\n                and config.person_detection_source is not None\n                else None\n            )\n        except Exception:\n''',
        "native input owner person source construction",
    )
    text = replace_once(
        text,
        '''            for close in (\n                getattr(camera_port, "stop", lambda: None),\n                getattr(lidar_port, "stop", lambda: None),\n''',
        '''            for close in (\n                getattr(person_detection_port, "stop", lambda: None),\n                getattr(camera_port, "stop", lambda: None),\n                getattr(lidar_port, "stop", lambda: None),\n''',
        "native input owner failure close order",
    )
    text = replace_once(
        text,
        '''        self._camera_source = camera_source\n        self._camera_port = camera_port\n        self._imu_device = imu_device\n''',
        '''        self._camera_source = camera_source\n        self._camera_port = camera_port\n        self._person_detection_source = person_detection_source\n        self._person_detection_port = person_detection_port\n        self._imu_device = imu_device\n''',
        "native input owner person attrs",
    )
    text = replace_once(
        text,
        '''    @property\n    def camera_frame_port(self) -> CameraFramePort | None:\n        return self._camera_port\n\n    @property\n    def auxiliary_sources(self) -> tuple[LiveDeviceSource, ...]:\n        return (self._camera_source,) if self._camera_source is not None else ()\n''',
        '''    @property\n    def camera_frame_port(self) -> CameraFramePort | None:\n        return self._camera_port\n\n    @property\n    def person_detection_source(self) -> NativePersonDetectionSource | None:\n        return self._person_detection_source\n\n    @property\n    def person_detection_port(self) -> PersonDetectionPort | None:\n        return self._person_detection_port\n\n    @property\n    def auxiliary_sources(self) -> tuple[LiveDeviceSource, ...]:\n        return tuple(\n            source\n            for source in (self._camera_source, self._person_detection_source)\n            if source is not None\n        )\n''',
        "native input owner person properties",
    )
    text = replace_once(
        text,
        '''        for close in (\n            getattr(self._camera_port, "stop", lambda: None),\n            self._lidar_port.stop,\n''',
        '''        for close in (\n            getattr(self._person_detection_port, "stop", lambda: None),\n            getattr(self._camera_port, "stop", lambda: None),\n            self._lidar_port.stop,\n''',
        "native input owner normal close order",
    )
    return text


def patch_bounded_config(text: str) -> str:
    text = replace_once(
        text,
        '''from v3.adapters.live_lidar import NativeLidarConfig\nfrom v3.adapters.live_camera import NativeCameraConfig\nfrom v3.adapters.picamera2_camera import (\n''',
        '''from v3.adapters.live_lidar import NativeLidarConfig\nfrom v3.adapters.live_camera import NativeCameraConfig\nfrom v3.adapters.live_person_detection import NativePersonDetectionConfig\nfrom v3.adapters.litert_person_detector import (\n    litert_person_detector_config_from_mapping,\n)\nfrom v3.adapters.person_photo_evidence import (\n    person_photo_evidence_config_from_mapping,\n)\nfrom v3.adapters.picamera2_camera import (\n''',
        "bounded config person imports",
    )
    text = replace_once(
        text,
        '''            camera_source = NativeCameraConfig(\n                "CAMERA_FRONT",\n                policy.camera_maximum_frame_age_ns,\n            )\n\n    inputs = NativeSensorInputConfig(\n''',
        '''            camera_source = NativeCameraConfig(\n                "CAMERA_FRONT",\n                policy.camera_maximum_frame_age_ns,\n            )\n\n    person_detection_backend = None\n    person_detection_source = None\n    person_photo_evidence = None\n    person_value = hardware.get("person_detection")\n    if person_value is not None:\n        person = _mapping(person_value, "hardware config person_detection")\n        allowed = {\n            "enabled",\n            "provider",\n            "model_path",\n            "person_class_id",\n            "score_threshold",\n            "max_detections",\n            "num_threads",\n            "maximum_result_age_ns",\n            "photo_evidence",\n        }\n        unknown = sorted(set(person) - allowed)\n        if unknown:\n            raise ValueError(\n                "unknown hardware person_detection keys: " + ", ".join(unknown)\n            )\n        person_enabled = person.get("enabled", False)\n        if type(person_enabled) is not bool:\n            raise ValueError("hardware config person_detection.enabled must be bool")\n        if person_enabled:\n            if camera_device is None:\n                raise ValueError("enabled person_detection requires enabled camera")\n            backend_keys = {\n                "enabled",\n                "provider",\n                "model_path",\n                "person_class_id",\n                "score_threshold",\n                "max_detections",\n                "num_threads",\n            }\n            person_detection_backend = litert_person_detector_config_from_mapping(\n                {key: person[key] for key in backend_keys if key in person}\n            )\n            person_detection_source = NativePersonDetectionConfig(\n                device_id="PERSON_DETECTOR_FRONT",\n                maximum_result_age_ns=_positive_int(\n                    person.get("maximum_result_age_ns", 500_000_000),\n                    "hardware config person_detection.maximum_result_age_ns",\n                ),\n            )\n            photo_value = person.get("photo_evidence")\n            if photo_value is not None:\n                parsed_photo = person_photo_evidence_config_from_mapping(photo_value)\n                if parsed_photo.enabled:\n                    person_photo_evidence = parsed_photo\n\n    inputs = NativeSensorInputConfig(\n''',
        "bounded config person parsing",
    )
    text = replace_once(
        text,
        '''        camera_source=camera_source,\n        lidar_source=NativeLidarConfig(\n''',
        '''        camera_source=camera_source,\n        person_detection_source=person_detection_source,\n        lidar_source=NativeLidarConfig(\n''',
        "bounded config person source wiring",
    )
    text = replace_once(
        text,
        '''        camera_device=camera_device,\n    )\n''',
        '''        camera_device=camera_device,\n        person_detection_backend=person_detection_backend,\n        person_photo_evidence=person_photo_evidence,\n    )\n''',
        "bounded config person hardware wiring",
    )
    return text


def patch_hardware_runtime(text: str) -> str:
    text = replace_once(
        text,
        '''from v3.adapters.picamera2_camera import (\n    NativePicamera2Camera,\n    Picamera2Factory,\n    default_picamera2_factory,\n    raspberry_pi_sensor_timestamp_to_monotonic_ns,\n)\n''',
        '''from v3.adapters.picamera2_camera import (\n    NativePicamera2Camera,\n    Picamera2Factory,\n    default_picamera2_factory,\n    raspberry_pi_sensor_timestamp_to_monotonic_ns,\n)\nfrom v3.adapters.litert_person_detector import LiteRtSsdPersonDetector\nfrom v3.adapters.person_detection import (\n    NativePersonDetector,\n    PersonDetectionPort,\n    UnavailablePersonDetectionPort,\n)\nfrom v3.adapters.person_photo_evidence import PersonPhotoEvidenceRecorder\n''',
        "hardware runtime person imports",
    )
    text = replace_once(
        text,
        '''    LifecycleState,\n    RobotEstimate,\n    TickContext,\n)\n''',
        '''    AdmittedFrame,\n    LifecycleState,\n    MissionIntent,\n    RobotEstimate,\n    TickContext,\n)\n''',
        "hardware runtime mission import",
    )
    text = replace_once(
        text,
        '''    __slots__ = ("_closed", "_inputs", "_pose_feedback")\n''',
        '''    __slots__ = ("_closed", "_inputs", "_person_evidence", "_pose_feedback")\n''',
        "hardware owner evidence slot",
    )
    text = replace_once(
        text,
        '''        camera: NativePicamera2Camera | None = None\n        inputs: NativeSensorInputOwner | None = None\n        pose_feedback = NativePoseFeedback(config.inputs.lidar_source.pose_frame_id)\n''',
        '''        camera: NativePicamera2Camera | None = None\n        person_detection_port: PersonDetectionPort | None = None\n        person_evidence: PersonPhotoEvidenceRecorder | None = None\n        inputs: NativeSensorInputOwner | None = None\n        pose_feedback = NativePoseFeedback(config.inputs.lidar_source.pose_frame_id)\n''',
        "hardware owner person locals",
    )
    text = replace_once(
        text,
        '''                # Camera is explicitly non-critical. A start failure remains\n                # visible as CAMERA_FRONT FAILED but must not abort core input\n                # ownership or the motor-control runtime.\n                camera.start()\n            inputs = NativeSensorInputOwner(\n                counter_gpio_backend,\n                imu,\n                lidar,\n                config.inputs,\n                camera_port=camera,\n            )\n''',
        '''                # Camera is explicitly non-critical. A start failure remains\n                # visible as CAMERA_FRONT FAILED but must not abort core input\n                # ownership or the motor-control runtime.\n                camera.start()\n\n            if config.person_detection_backend is not None:\n                assert config.inputs.person_detection_source is not None\n                if camera is None or not camera.get_runtime_status().running:\n                    camera_error = (\n                        camera.get_runtime_status().last_error\n                        if camera is not None\n                        else "camera capability unavailable"\n                    )\n                    person_detection_port = UnavailablePersonDetectionPort(\n                        f"PERSON_DETECTOR_CAMERA_UNAVAILABLE:{camera_error}"\n                    )\n                else:\n                    detector: NativePersonDetector | None = None\n                    try:\n                        backend = LiteRtSsdPersonDetector(\n                            config.person_detection_backend\n                        )\n                        detector = NativePersonDetector(camera, backend)\n                        if not detector.start():\n                            raise RuntimeError("person detector worker did not start")\n                        person_detection_port = detector\n                    except Exception as exc:\n                        if detector is not None:\n                            try:\n                                detector.stop()\n                            except Exception:\n                                pass\n                        # Detector/model/runtime failures are capability-local.\n                        # TELEOP/EXPLORE motor availability is unchanged because\n                        # PERSON_DETECTOR_FRONT is not production-critical.\n                        person_detection_port = UnavailablePersonDetectionPort(\n                            f"{type(exc).__name__}:{exc}"\n                        )\n\n                if config.person_photo_evidence is not None:\n                    person_evidence = PersonPhotoEvidenceRecorder(\n                        camera,\n                        config.person_photo_evidence,\n                        source_device_id=(\n                            config.inputs.person_detection_source.device_id\n                        ),\n                    )\n\n            inputs = NativeSensorInputOwner(\n                counter_gpio_backend,\n                imu,\n                lidar,\n                config.inputs,\n                camera_port=camera,\n                person_detection_port=person_detection_port,\n            )\n''',
        "hardware owner person construction",
    )
    text = replace_once(
        text,
        '''            else:\n                if camera is not None:\n                    try:\n                        camera.stop()\n                    except Exception:\n                        pass\n                if lidar is not None:\n''',
        '''            else:\n                if person_detection_port is not None:\n                    try:\n                        person_detection_port.stop()\n                    except Exception:\n                        pass\n                if camera is not None:\n                    try:\n                        camera.stop()\n                    except Exception:\n                        pass\n                if lidar is not None:\n''',
        "hardware owner person cleanup",
    )
    text = replace_once(
        text,
        '''        self._inputs = inputs\n        self._pose_feedback = pose_feedback\n        self._closed = False\n''',
        '''        self._inputs = inputs\n        self._pose_feedback = pose_feedback\n        self._person_evidence = person_evidence\n        self._closed = False\n''',
        "hardware owner person evidence attr",
    )
    text = replace_once(
        text,
        '''        estimate = _layer_output(result, "L3")\n        if isinstance(estimate, RobotEstimate):\n            self._pose_feedback.publish(estimate)\n''',
        '''        estimate = _layer_output(result, "L3")\n        if isinstance(estimate, RobotEstimate):\n            self._pose_feedback.publish(estimate)\n        admitted = _layer_output(result, "L2")\n        mission = _layer_output(result, "L5")\n        if (\n            self._person_evidence is not None\n            and isinstance(admitted, AdmittedFrame)\n            and isinstance(mission, MissionIntent)\n        ):\n            self._person_evidence.observe(admitted, mission)\n''',
        "hardware owner passive evidence observation",
    )
    return text


def patch_requirements(text: str) -> str:
    expected = "# Native R2B4 V3 runtime and validation dependencies\nlgpio\nnumpy\npyserial\nscipy\nsmbus2\npytest\n"
    if text != expected:
        raise UpgradeError("requirements.txt differs from analysed baseline")
    return (
        "# Native R2B4 V3 runtime and validation dependencies\n"
        "ai-edge-litert==2.2.0\n"
        "lgpio\n"
        "numpy==1.24.2\n"
        "pyserial\n"
        "scipy==1.10.1\n"
        "smbus2\n"
        "pytest\n"
    )


def patch_gitignore(text: str) -> str:
    addition = "\n# Local ML model binaries and camera evidence\n/models/*.tflite\n/pic/\n"
    if "/models/*.tflite" in text or "/pic/" in text:
        raise UpgradeError(".gitignore already contains person-detection local-data rules")
    return text.rstrip("\n") + "\n" + addition


def patch_hardware_json(text: str) -> str:
    try:
        document = json.loads(text)
    except json.JSONDecodeError as exc:
        raise UpgradeError(f"conf/hardver.json is invalid JSON: {exc}") from exc
    if not isinstance(document, dict):
        raise UpgradeError("conf/hardver.json must contain an object")
    if "person_detection" in document:
        raise UpgradeError("conf/hardver.json already contains person_detection")
    camera = document.get("camera")
    if not isinstance(camera, dict) or camera.get("enabled") is not True:
        raise UpgradeError("person detection upgrade requires enabled camera config")
    document["person_detection"] = {
        "enabled": True,
        "provider": "litert_ssd",
        "model_path": "models/efficientdet_lite0.tflite",
        "person_class_id": 0,
        "score_threshold": 0.45,
        "max_detections": 5,
        "num_threads": 2,
        "maximum_result_age_ns": 500000000,
        "photo_evidence": {
            "enabled": True,
            "directory": "pic",
            "stream_name": "main",
            "confirm_results": 3,
            "rearm_misses": 5,
            "minimum_interval_ns": 5000000000,
        },
    }
    return json.dumps(document, ensure_ascii=False, indent=2) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="R2B4 repository root")
    parser.add_argument(
        "--check",
        action="store_true",
        help="verify all source anchors without writing files",
    )
    args = parser.parse_args()
    root = Path(args.root).resolve()
    if not (root / "v3").is_dir() or not (root / "AGENTS.md").is_file():
        raise UpgradeError(f"not an R2B4 repository root: {root}")

    for relative in (
        "v3/adapters/person_detection.py",
        "v3/adapters/litert_person_detector.py",
        "v3/adapters/live_person_detection.py",
        "tests/test_v3_person_detection.py",
    ):
        read_text(root, relative)

    guard = read_text(root, "v3/import_guard.py")
    guard_requirements = (
        '"v3.adapters.litert_person_detector": frozenset({"ai_edge_litert"})',
        '"v3.layers.l12_safety_final": frozenset({"v3.device_health_policy"})',
    )
    missing_guard = [item for item in guard_requirements if item not in guard]
    if missing_guard:
        raise UpgradeError(
            "current import_guard is missing the required narrow person/L12 permissions; "
            "update to the analysed main baseline first"
        )

    try:
        head = subprocess.check_output(
            ["git", "-C", str(root), "rev-parse", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        head = "UNKNOWN"
    if head != BASELINE:
        print(
            f"WARNING: analysed baseline is {BASELINE[:12]}, local HEAD is {head[:12]}; "
            "exact source anchors will decide whether the upgrade is safe to apply.",
            file=sys.stderr,
        )

    transforms = {
        "v3/adapters/person_detection.py": patch_person_detection,
        "v3/adapters/picamera2_camera.py": patch_picamera2_camera,
        "v3/composition/native_sensor_inputs.py": patch_native_sensor_inputs,
        "v3_bounded_config.py": patch_bounded_config,
        "v3_hardware_runtime.py": patch_hardware_runtime,
        "requirements.txt": patch_requirements,
        ".gitignore": patch_gitignore,
        "conf/hardver.json": patch_hardware_json,
    }

    # Transactional preparation: no write until every transform and new-file
    # collision check has passed.  Original target contents are retained for
    # best-effort rollback if a later filesystem write fails.
    prepared: dict[Path, str] = {}
    originals: dict[Path, str | None] = {}
    for relative, transform in transforms.items():
        target = root / relative
        original = read_text(root, relative)
        originals[target] = original
        prepared[target] = transform(original)

    new_files = {
        "v3/adapters/person_photo_evidence.py": (
            PACKAGE_ROOT / "files" / "v3" / "adapters" / "person_photo_evidence.py"
        ),
        "tests/test_v3_person_detection_runtime_integration.py": (
            PACKAGE_ROOT / "files" / "tests" / "test_v3_person_detection_runtime_integration.py"
        ),
    }
    for relative, source in new_files.items():
        if not source.is_file():
            raise UpgradeError(f"package is incomplete: {source}")
        target = root / relative
        content = source.read_text(encoding="utf-8")
        if target.exists():
            if target.is_symlink() or not target.is_file():
                raise UpgradeError(f"new-file target is not a regular file: {relative}")
            existing = target.read_text(encoding="utf-8")
            if existing != content:
                raise UpgradeError(f"refusing to overwrite existing different file: {relative}")
            originals[target] = existing
        else:
            originals[target] = None
        prepared[target] = content

    # Parse every Python result before touching the working tree.
    import ast

    for path, content in prepared.items():
        if path.suffix == ".py":
            try:
                ast.parse(content, filename=str(path))
            except SyntaxError as exc:
                raise UpgradeError(f"generated Python is invalid for {path}: {exc}") from exc

    if args.check:
        print(f"CHECK PASS: {len(prepared)} files are applicable")
        return 0

    written: list[Path] = []
    try:
        for path, content in prepared.items():
            atomic_write(path, content)
            written.append(path)
    except BaseException as exc:
        rollback_errors: list[str] = []
        for path in reversed(written):
            original = originals[path]
            try:
                if original is None:
                    path.unlink(missing_ok=True)
                else:
                    atomic_write(path, original)
            except BaseException as rollback_exc:
                rollback_errors.append(f"{path}: {rollback_exc}")
        detail = ""
        if rollback_errors:
            detail = "; rollback errors: " + " | ".join(rollback_errors)
        raise UpgradeError(f"filesystem write failed: {exc}{detail}") from exc

    print(f"UPGRADE APPLIED: {len(prepared)} files")
    print("No commit or push was performed.")
    print("Next: run the validation commands from README_UPGRADE.md")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except UpgradeError as exc:
        print(f"UPGRADE REFUSED: {exc}", file=sys.stderr)
        raise SystemExit(2)
