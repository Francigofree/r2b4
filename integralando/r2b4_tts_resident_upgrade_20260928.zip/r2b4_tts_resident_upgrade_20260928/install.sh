#!/usr/bin/env bash
set -euo pipefail

UPGRADE_ID="tts_resident_plain_v1_20260928"
BASE_COMMIT="a8e2f49fe7d9b169a9cb93d5ba20ce0c32478f94"
BASE_PLAIN_BLOB="0a9adbc95ed0b16fc77631dcff8e70aee75ebddd"
BASE_PROVIDER_BLOB="67adc3e6fc2d1bcbb502189c7052be2c93c10375"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-${R2B4_ROOT:-/home/alba/project_r2b4}}"
ROOT="$(cd "$ROOT" && pwd)"
PAYLOAD="$HERE/payload"

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

[[ -d "$ROOT/.git" ]] || fail "not a git worktree: $ROOT"
[[ -f "$ROOT/r2b4_voice/plain_llm.py" ]] || fail "missing r2b4_voice/plain_llm.py"
[[ -f "$ROOT/r2b4_voice/tts_provider.py" ]] || fail "missing r2b4_voice/tts_provider.py"

payload_hash() { git -C "$ROOT" hash-object "$1"; }
target_hash() { git -C "$ROOT" hash-object "$1"; }

# Idempotent re-run: if every installed file is byte-identical, do nothing.
all_installed=1
for rel in \
  r2b4_voice/plain_llm.py \
  r2b4_voice/tts_provider.py \
  r2b4_voice/resident_tts.py \
  r2b4_voice/tts_daemon.py \
  tests/feature/test_resident_tts.py
do
  [[ -f "$ROOT/$rel" ]] || { all_installed=0; break; }
  [[ "$(target_hash "$ROOT/$rel")" == "$(payload_hash "$PAYLOAD/$rel")" ]] || { all_installed=0; break; }
done
if [[ "$all_installed" == 1 ]]; then
  echo "$UPGRADE_ID: already installed; no changes made."
  exit 0
fi

plain_blob="$(target_hash "$ROOT/r2b4_voice/plain_llm.py")"
provider_blob="$(target_hash "$ROOT/r2b4_voice/tts_provider.py")"
[[ "$plain_blob" == "$BASE_PLAIN_BLOB" ]] || fail "plain_llm.py is not the source-first base ($plain_blob != $BASE_PLAIN_BLOB); refusing to overwrite"
[[ "$provider_blob" == "$BASE_PROVIDER_BLOB" ]] || fail "tts_provider.py is not the source-first base ($provider_blob != $BASE_PROVIDER_BLOB); refusing to overwrite"

for rel in r2b4_voice/resident_tts.py r2b4_voice/tts_daemon.py tests/feature/test_resident_tts.py; do
  [[ ! -e "$ROOT/$rel" ]] || fail "$rel already exists and differs from this upgrade; refusing to overwrite"
done

stamp="$(date +%Y%m%d_%H%M%S)"
backup="$ROOT/.upgrade_backups/tts_resident_plain_v1_${stamp}"
mkdir -p "$backup/r2b4_voice"
cp -a "$ROOT/r2b4_voice/plain_llm.py" "$backup/r2b4_voice/plain_llm.py"
cp -a "$ROOT/r2b4_voice/tts_provider.py" "$backup/r2b4_voice/tts_provider.py"
cat > "$backup/BASE.txt" <<EOF
upgrade_id=$UPGRADE_ID
base_commit=$BASE_COMMIT
plain_blob=$BASE_PLAIN_BLOB
provider_blob=$BASE_PROVIDER_BLOB
installed_at=$(date -Is)
EOF

rollback_current() {
  echo "Validation failed; restoring backup: $backup" >&2
  cp -a "$backup/r2b4_voice/plain_llm.py" "$ROOT/r2b4_voice/plain_llm.py"
  cp -a "$backup/r2b4_voice/tts_provider.py" "$ROOT/r2b4_voice/tts_provider.py"
  rm -f "$ROOT/r2b4_voice/resident_tts.py" "$ROOT/r2b4_voice/tts_daemon.py" "$ROOT/tests/feature/test_resident_tts.py"
  rm -rf "$ROOT/r2b4_voice/__pycache__" "$ROOT/tests/feature/__pycache__"
}

mkdir -p "$ROOT/r2b4_voice" "$ROOT/tests/feature"
cp "$PAYLOAD/r2b4_voice/plain_llm.py" "$ROOT/r2b4_voice/plain_llm.py"
cp "$PAYLOAD/r2b4_voice/tts_provider.py" "$ROOT/r2b4_voice/tts_provider.py"
cp "$PAYLOAD/r2b4_voice/resident_tts.py" "$ROOT/r2b4_voice/resident_tts.py"
cp "$PAYLOAD/r2b4_voice/tts_daemon.py" "$ROOT/r2b4_voice/tts_daemon.py"
cp "$PAYLOAD/tests/feature/test_resident_tts.py" "$ROOT/tests/feature/test_resident_tts.py"
chmod 0644 \
  "$ROOT/r2b4_voice/plain_llm.py" \
  "$ROOT/r2b4_voice/tts_provider.py" \
  "$ROOT/r2b4_voice/resident_tts.py" \
  "$ROOT/r2b4_voice/tts_daemon.py" \
  "$ROOT/tests/feature/test_resident_tts.py"

if ! python3 -m py_compile \
  "$ROOT/r2b4_voice/plain_llm.py" \
  "$ROOT/r2b4_voice/tts_provider.py" \
  "$ROOT/r2b4_voice/resident_tts.py" \
  "$ROOT/r2b4_voice/tts_daemon.py" \
  "$ROOT/tests/feature/test_resident_tts.py"; then
  rollback_current
  fail "py_compile failed; upgrade rolled back"
fi

if python3 -c 'import pytest' >/dev/null 2>&1; then
  if ! (cd "$ROOT" && python3 -m pytest -q \
      tests/feature/test_local_tts_provider.py \
      tests/feature/test_plain_llm_launcher.py \
      tests/feature/test_resident_tts.py); then
    rollback_current
    fail "targeted pytest failed; upgrade rolled back"
  fi
else
  echo "WARNING: pytest is unavailable; syntax validation passed, targeted tests skipped." >&2
fi

# No previous version of this sidecar should survive an upgrade/re-install.
pkill -f 'r2b4_voice[.]tts_daemon' 2>/dev/null || true
rm -f "${XDG_RUNTIME_DIR:-/tmp}"/r2b4-tts-"$(id -u)"-*.sock 2>/dev/null || true

printf '\n%s installed successfully.\n' "$UPGRADE_ID"
printf 'Backup: %s\n' "$backup"
printf 'Source-first base commit: %s\n' "$BASE_COMMIT"
printf 'Test now: cd %q && ./r "Csak ezt válaszold: teszt."\n' "$ROOT"
