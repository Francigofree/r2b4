# R2B4 plain `r` lokális TTS latency/reliability upgrade

**Upgrade:** `tts_resident_plain_v1_20260928`  
**Source-first ellenőrzött HEAD:** `Francigofree/r2b4` `main` commit `a8e2f49fe7d9b169a9cb93d5ba20ce0c32478f94`

Az elemzés a `6dad25d9d34035c6753f5fb7e85c59a51651d652` commitnál indult; csomagoláskor a HEAD előrelépett, de az érintett forrásfájlok Git blob-hash-ei változatlanok maradtak.

## Bizonyított gyökérok

A friss forrásban a sima `r "..."` útvonal:

`r -> v3.launcher_cli -> r2b4_voice.plain_llm.run_plain_prompt -> Piper -> PcmWavePlayer`

A `PcmWavePlayer` már eleve blokkoló `subprocess.run(...)` lejátszást használ, és a temp WAV-ot csak a lejátszó visszatérése után törli. Ezt az upgrade nem módosítja.

A tényleges latency-probléma a plain launcher útban volt:

1. minden új `r "..."` processz újra betöltötte a Piper/ONNX modellt;
2. a TTS csak a teljes Gemini-válasz beérkezése/kiírása után épült fel;
3. a plain út akár 1800 karakteres darabot is teljesen leszintetizált, mielőtt elindult volna a lejátszás.

## Mit változtat

- Új, host-only rezidens Piper sidecar: `r2b4_voice.tts_daemon`.
- Unix socketen PCM-et ad vissza; **nem** birtokol mikrofont, hangszórót, V3-at vagy robot-control authority-t.
- A plain `r "..."` első hívásakor a Piper modell betöltése a Gemini hálózati kérésével párhuzamosan indul.
- A következő `r "..."` hívások ugyanazt a már betöltött ONNX modellt használják.
- A válasz beszéde kb. 320 karakteres, mondathatár-közeli darabokban indul, ezért hosszabb válasznál nem kell az egész hangot előre legenerálni.
- A meglévő blokkoló `PcmWavePlayer` változatlan marad.
- Ha a rezidens sidecar nem indul vagy nem érhető el, automatikusan visszaesik a jelenlegi közvetlen lokális Piper útra.
- A long-running voice service és ER2 default TTS wiringja nem változik; a rezidens módot csak a rövid életű plain launcher kéri.

## Telepítés

Másold a csomagot a Raspberry Pi-re, majd:

```bash
cd /home/alba/project_r2b4
unzip -q /útvonal/r2b4_tts_resident_upgrade_20260928.zip -d /tmp/r2b4_tts_upgrade
bash /tmp/r2b4_tts_upgrade/r2b4_tts_resident_upgrade_20260928/install.sh
```

A telepítő:

- ellenőrzi a két módosítandó jelenlegi forrás Git blob-hashét;
- eltérés esetén **nem ír felül semmit**;
- automatikus backupot készít `.upgrade_backups/tts_resident_plain_v1_<idő>/` alatt;
- `py_compile`-t és – ha pytest elérhető – célzott regressziós teszteket futtat;
- teszthiba esetén automatikusan visszaállítja az eredeti két fájlt.

## Élő acceptance

Első hívás (első modellbetöltés, már a Gemini-kérés alatt):

```bash
cd /home/alba/project_r2b4
time ./r "Csak ezt válaszold: teszt."
```

Második hívás (resident/hot modell):

```bash
time ./r "Csak ezt válaszold: második teszt."
```

Sidecar ellenőrzése:

```bash
pgrep -af 'r2b4_voice.tts_daemon'
ls -l "${XDG_RUNTIME_DIR:-/tmp}"/r2b4-tts-"$(id -u)"-*.sock 2>/dev/null
```

Elvárt eredmény:

- a második `r` hívásnál nincs új ONNX-modellbetöltés a launcher processzben;
- a TTS a szöveg kiírása után lényegesen hamarabb indul;
- hosszabb válaszoknál a beszéd darabonként indul;
- a shell csak a blokkoló lejátszás befejezése után tér vissza.

Az első sidecar-indítás ONNX figyelmeztetései – ha vannak – nem a launcher stdout/stderr-jére, hanem ide kerülnek:

```bash
ls -lt /tmp/r2b4-tts-*.log | head
```

## Rollback

```bash
bash /tmp/r2b4_tts_upgrade/r2b4_tts_resident_upgrade_20260928/rollback.sh
```

A rollback leállítja a resident TTS sidecart, visszaállítja a legutóbbi upgrade-backup két eredeti fájlját, és eltávolítja az upgrade új moduljait/tesztjét.
