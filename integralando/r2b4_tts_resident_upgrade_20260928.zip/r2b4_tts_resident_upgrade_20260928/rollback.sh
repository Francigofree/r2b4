#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-${R2B4_ROOT:-/home/alba/project_r2b4}}"
ROOT="$(cd "$ROOT" && pwd)"
backup="$(find "$ROOT/.upgrade_backups" -maxdepth 1 -mindepth 1 -type d -name 'tts_resident_plain_v1_*' -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -n1 | cut -d' ' -f2-)"
[[ -n "$backup" ]] || { echo "ERROR: no tts_resident_plain_v1 backup found" >&2; exit 1; }
[[ -f "$backup/r2b4_voice/plain_llm.py" ]] || { echo "ERROR: invalid backup: $backup" >&2; exit 1; }
[[ -f "$backup/r2b4_voice/tts_provider.py" ]] || { echo "ERROR: invalid backup: $backup" >&2; exit 1; }

pkill -f 'r2b4_voice[.]tts_daemon' 2>/dev/null || true
rm -f "${XDG_RUNTIME_DIR:-/tmp}"/r2b4-tts-"$(id -u)"-*.sock 2>/dev/null || true
cp -a "$backup/r2b4_voice/plain_llm.py" "$ROOT/r2b4_voice/plain_llm.py"
cp -a "$backup/r2b4_voice/tts_provider.py" "$ROOT/r2b4_voice/tts_provider.py"
rm -f "$ROOT/r2b4_voice/resident_tts.py" "$ROOT/r2b4_voice/tts_daemon.py" "$ROOT/tests/feature/test_resident_tts.py"
rm -rf "$ROOT/r2b4_voice/__pycache__" "$ROOT/tests/feature/__pycache__"
python3 -m py_compile "$ROOT/r2b4_voice/plain_llm.py" "$ROOT/r2b4_voice/tts_provider.py"
echo "Rollback complete from: $backup"
