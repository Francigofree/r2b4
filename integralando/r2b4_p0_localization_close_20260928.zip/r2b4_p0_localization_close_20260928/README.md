# R2B4 P0 dual-frame localization close-out

Upgrade ID: `R2B4_P0_DUAL_FRAME_CLOSE_20260928`

Source-first base:

- repository: `Francigofree/r2b4`
- branch: `main`
- commit: `c020bfa712a489aaf72c69e7bcf9920f2f8d87b1`

This package implements only the agreed P0 close-out changes. It deliberately does **not** apply the P1 structural-memory, contract-hardening, slip-hysteresis, or status/evidence changes.

## Changes

1. `tests/deep/test_v3_lidar_world_replay.py`
   - fixes the test-only capture terminal status from `STOP` to `PASS`;
   - keeps the production capture contract strict (`PASS/FAIL/FAULT` only).

2. `v3/launcher_cli.py`
   - obvious near-command typos are rejected locally before the plain Gemini fallback;
   - detection cutoff is 0.8, so `statuz` is treated as a likely `status` typo, while ordinary text such as `hello` remains a plain-LLM prompt;
   - the existing looser 0.6 suggestion list remains for the error message.

3. `tests/feature/test_plain_llm_launcher.py`
   - proves `statuz` never reaches the plain LLM;
   - proves `hello` still reaches the plain LLM.

4. `tests/feature/test_v3_latest_lidar_backend.py`
   - adds production-adapter acceptance for `relative_motion`;
   - with `tracking_ready=False`, local physical LiDAR and `lidar_relative_motion` remain published while `lidar_pose` is withheld.

5. `v3/layers/l6_navigation.py`
   - a global NAVIGATE target cannot silently fall through into local coordinates when `map_to_odom` is absent;
   - returns `NavigationStatus.INVALIDATED` with `GLOBAL_TRANSFORM_MISSING`.

6. `tests/feature/test_v3_dual_frame_localization.py`
   - proves the missing-transform global target becomes zero-motion downstream;
   - proves a local-frame NAVIGATE target remains valid without the global transform.

## Apply

```bash
unzip r2b4_p0_localization_close_20260928.zip -d /tmp/r2b4_p0_close
python3 /tmp/r2b4_p0_close/r2b4_p0_localization_close_20260928/apply_upgrade.py --check /home/alba/project_r2b4
python3 /tmp/r2b4_p0_close/r2b4_p0_localization_close_20260928/apply_upgrade.py /home/alba/project_r2b4
```

The installer checks the exact Git blob SHA of every target file before writing. If the local files differ from the source-first base, it stops without modifying anything.

Backups are written under:

```text
/home/alba/project_r2b4/.upgrade_backups/p0_dual_frame_close_YYYYMMDD_HHMMSS/
```

## Verify

Targeted P0 regression:

```bash
bash /tmp/r2b4_p0_close/r2b4_p0_localization_close_20260928/verify.sh /home/alba/project_r2b4
```

Targeted + full regression:

```bash
bash /tmp/r2b4_p0_close/r2b4_p0_localization_close_20260928/verify.sh /home/alba/project_r2b4 --full
```

Final acceptance gate:

- launcher typo test passes and does not call Gemini;
- plain free text still routes to Gemini;
- relative LiDAR motion survives the production adapter path independently from global pose publication;
- global NAVIGATE without `map_to_odom` is invalidated and produces zero requested motion;
- local NAVIGATE remains usable without `map_to_odom`;
- 601-second simulated Room Cruise capture reaches replay and returns `MATCH`;
- `r test full` is fully green.
