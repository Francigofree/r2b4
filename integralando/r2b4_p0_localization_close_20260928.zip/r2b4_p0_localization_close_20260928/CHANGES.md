# P0 implementation diff summary

## Capture replay test

```diff
- sink.finalize('STOP', ...)
+ sink.finalize('PASS', ...)
```

No production capture-status contract is changed.

## Launcher typo gate

Adds `_command_names()` and `_looks_like_command_typo()`.

Dispatch order for an otherwise unknown first token becomes:

```text
known robot command -> robot path
near known command (cutoff 0.8) -> local unknown-command error, rc=2
other text -> plain Gemini path
```

Explicit `r -- "..."` remains an unconditional plain-prompt escape.

## Relative LiDAR production-path acceptance

Adds a test with:

```text
tracking_ready=False
relative_motion=valid
```

Expected:

```text
lidar_safety_clearance: present
lidar_local_points:     present
lidar_relative_motion:  present
lidar_pose:             absent
```

## Global NAVIGATE fail-closed

Changes L6 target transformation from an optional transform to an explicit requirement for non-local NAVIGATE targets:

```text
global target + map_to_odom missing
    -> INVALIDATED / GLOBAL_TRANSFORM_MISSING
    -> downstream requested v=0, omega=0
```

Local-frame targets do not require `map_to_odom`.
