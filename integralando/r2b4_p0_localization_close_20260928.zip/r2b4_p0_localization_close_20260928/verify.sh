#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/home/alba/project_r2b4}"
MODE="${2:-targeted}"
cd "$ROOT"

if command -v r >/dev/null 2>&1; then
  R=(r)
elif [[ -x "$ROOT/r" ]]; then
  R=("$ROOT/r")
else
  echo "ERROR: r launcher not found" >&2
  exit 2
fi

echo "=== P0 targeted regression ==="
"${R[@]}" pytest -q \
  tests/feature/test_launcher_workflows.py::test_help_discovery_and_typo_never_start_robot_or_host_tools \
  tests/feature/test_plain_llm_launcher.py \
  tests/feature/test_v3_latest_lidar_backend.py \
  tests/feature/test_v3_dual_frame_localization.py \
  tests/deep/test_v3_lidar_world_replay.py::test_roomcruise_localization_ten_minute_simulation_and_replay

if [[ "$MODE" == "--full" || "$MODE" == "full" ]]; then
  echo "=== Full regression ==="
  "${R[@]}" test full
else
  echo
  echo "Targeted PASS. Final P0 gate:"
  echo "  $ROOT/r test full"
fi
