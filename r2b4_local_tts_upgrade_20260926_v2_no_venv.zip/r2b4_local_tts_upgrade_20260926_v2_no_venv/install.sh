#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-${R2B4_ROOT:-/home/alba/project_r2b4}}"
ROOT="$(readlink -f "$ROOT")"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="${R2B4_PYTHON:-/usr/bin/python3}"
VOICE="${R2B4_PIPER_VOICE:-hu_HU-anna-medium}"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
DATA_DIR="${R2B4_PIPER_DATA_DIR:-$DATA_HOME/r2b4/piper}"
PYTHON_DIR="${R2B4_PIPER_PYTHON_DIR:-$DATA_DIR/python}"
MODEL="${R2B4_PIPER_MODEL_PATH:-$DATA_DIR/$VOICE.onnx}"
CONFIG="$MODEL.json"

if [[ ! -x "$PYTHON" ]]; then
  echo "ERROR: Python not executable: $PYTHON" >&2
  exit 2
fi
if [[ ! -d "$ROOT/.git" ]]; then
  echo "ERROR: R2B4 repo not found: $ROOT" >&2
  exit 2
fi

printf '== R2B4 local TTS bootstrap (PEP-668 safe, no venv) ==\n'
printf 'root: %s\npython: %s\nvoice: %s\nmodel: %s\npiper python target: %s\n' \
  "$ROOT" "$PYTHON" "$VOICE" "$MODEL" "$PYTHON_DIR"

mkdir -p "$DATA_DIR" "$PYTHON_DIR"

# PEP 668: install outside every sysconfig scheme. This is deliberately NOT
# --user, NOT system-wide, NOT a venv, and does not use --break-system-packages.
if ! PYTHONPATH="$PYTHON_DIR${PYTHONPATH:+:$PYTHONPATH}" "$PYTHON" - <<'PY'
import importlib.metadata
try:
    assert importlib.metadata.version("piper-tts") == "1.8.0"
    import piper
    assert hasattr(piper, "PiperVoice")
except Exception:
    raise SystemExit(1)
PY
then
  echo "Installing piper-tts==1.8.0 into dedicated R2B4 target (no venv)..."
  rm -rf "$PYTHON_DIR/.r2b4_piper_install_tmp"
  if ! "$PYTHON" -m pip install \
      --target "$PYTHON_DIR" \
      --upgrade \
      --only-binary=:all: \
      "piper-tts==1.8.0"; then
    echo "ERROR: piper-tts dedicated-target installation failed." >&2
    exit 3
  fi
fi

if ! PYTHONPATH="$PYTHON_DIR${PYTHONPATH:+:$PYTHONPATH}" "$PYTHON" - <<'PY'
from piper import PiperVoice
print("Piper Python API: PASS")
PY
then
  echo "ERROR: Piper is not importable from $PYTHON_DIR" >&2
  exit 3
fi

if [[ ! -f "$MODEL" || ! -f "$CONFIG" ]]; then
  echo "Downloading official Piper voice $VOICE..."
  PYTHONPATH="$PYTHON_DIR${PYTHONPATH:+:$PYTHONPATH}" \
    "$PYTHON" -m piper.download_voices --data-dir "$DATA_DIR" "$VOICE"
fi

if [[ ! -f "$MODEL" || ! -f "$CONFIG" ]]; then
  echo "ERROR: Piper voice download did not produce model+config." >&2
  exit 4
fi

export R2B4_PIPER_PYTHON_DIR="$PYTHON_DIR"
"$PYTHON" "$HERE/apply_upgrade.py" "$ROOT"

echo
echo "Diagnostic snapshot (does not call cloud APIs):"
set +e
(cd "$ROOT" && "$PYTHON" -m r2b4_voice.voice_service --check)
CHECK_RC=$?
set -e
if [[ $CHECK_RC -ne 0 ]]; then
  echo "NOTE: --check reported another missing dependency/device/key; the source upgrade itself was applied and tested."
fi

echo
echo "PASS: default TTS is now local Piper."
echo "Piper packages: $PYTHON_DIR"
echo "Piper voice:    $MODEL"
echo "Gemini TTS remains opt-in with R2B4_TTS_PROVIDER=gemini."
