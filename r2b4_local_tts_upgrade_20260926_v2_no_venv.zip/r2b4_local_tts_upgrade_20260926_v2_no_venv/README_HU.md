# R2B4 lokális Piper TTS upgrade — PEP 668 kompatibilis, venv nélkül

Alap: `Francigofree/r2b4` main @ `d0213cdf351114f348b89f8aa075f38bdf7677b8`.

## Cél

A teljes aktív R2B4 beszédkimenet alapértelmezett TTS-e helyi Piper legyen:

- normál `r2b4_voice.voice_service`;
- ER2 `--speak` / `Er2SpeechReporter`;
- a meglévő `PcmWavePlayer` / PipeWire lejátszási út változatlan marad;
- Gemini TTS csak explicit `R2B4_TTS_PROVIDER=gemini` választással marad meg.

## Fontos: nincs venv és nincs `--break-system-packages`

A Raspberry Pi OS / Debian PEP 668 miatt a csomag **nem** használ `pip --user` telepítést.
A Piper Python csomagjai külön alkalmazáskönyvtárba kerülnek:

```text
~/.local/share/r2b4/piper/python/
```

Telepítési mód:

```bash
/usr/bin/python3 -m pip install \
  --target ~/.local/share/r2b4/piper/python \
  --upgrade --only-binary=:all: \
  piper-tts==1.8.0
```

Ez nem virtuális környezet, nem ír `/usr/lib/python*` vagy a Debian által kezelt Python-csomagok közé, és nem igényli a PEP 668 védelem felülbírálását. Az R2B4 TTS adapter csak akkor adja hozzá ezt a célkönyvtárat az import keresési útvonal végéhez, amikor a Piper szükséges.

Default voice:

```text
hu_HU-anna-medium
```

Default adatok:

```text
~/.local/share/r2b4/piper/
├── hu_HU-anna-medium.onnx
├── hu_HU-anna-medium.onnx.json
└── python/                  # Piper + kizárólagos Python függőségei
```

## Telepítés

```bash
cd /home/alba/project_r2b4
unzip r2b4_local_tts_upgrade_20260926_v2_no_venv.zip -d /tmp
/tmp/r2b4_local_tts_upgrade_20260926_v2_no_venv/install.sh /home/alba/project_r2b4
```

Az installer:

1. külön `--target` könyvtárba telepíti a `piper-tts==1.8.0` csomagot;
2. az official Piper downloaderrel letölti a magyar modellt;
3. csak ezután módosítja a repót;
4. ellenőrzi a source blob SHA-kat, ezért eltérő érintett source-ot nem ír felül;
5. backupot készít `runtime/upgrade_backups/` alatt;
6. `py_compile` + célzott pytest validációt futtat;
7. source-validációs hiba esetén automatikusan rollbackel.

## Ellenőrzés

```bash
cd /home/alba/project_r2b4
python3 -m r2b4_voice.voice_service --check
```

Elvárt TTS mezők:

```text
tts_provider: piper
tts_model: piper-tts
tts_voice: hu_HU-anna-medium
tts_api_key: NOT_REQUIRED
tts_dependency: PASS
tts_model_file: PASS
tts_status: PASS
```

Ha a voice service systemd-ből fut:

```bash
systemctl --user restart r2b4-wake.service
```

ER2 teszt:

```bash
./r er2 "Mondd röviden, hogy a helyi TTS működik." --speak
```

## Gemini TTS opcionális visszakapcsolása

```bash
export R2B4_TTS_PROVIDER=gemini
```

vagy a meglévő `conf/.wake.env` fájlban:

```text
R2B4_TTS_PROVIDER=gemini
```

A Piper az alapértelmezett; nincs automatikus cloud fallback.
