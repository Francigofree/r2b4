#!/usr/bin/env python3
"""Apply the source-first R2B4 local Piper TTS upgrade.

Base: Francigofree/r2b4 main @ d0213cdf351114f348b89f8aa075f38bdf7677b8
Only host-side TTS wiring is changed. Existing local changes to touched files cause
an explicit refusal instead of being overwritten.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import time
from pathlib import Path

BASE_COMMIT = "d0213cdf351114f348b89f8aa075f38bdf7677b8"
EXPECTED_BLOBS = {
    "r2b4_voice/voice_service.py": "d0ca4f41cfe845dea0546515377f52a4a507fd82",
    "r2b4_er2/speech.py": "03111f84af5018ef071446f234015b8bf431096f",
}
NEW_FILES = (
    "r2b4_voice/piper_tts.py",
    "r2b4_voice/tts_provider.py",
    "tests/feature/test_local_tts_provider.py",
    "tests/feature/test_er2_local_tts_wiring.py",
)


def run(cmd: list[str], *, cwd: Path, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=cwd, text=True, capture_output=True, check=check)


def git_blob(root: Path, rel: str) -> str:
    result = run(["git", "hash-object", "--", rel], cwd=root)
    return result.stdout.strip()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one source match, found {count}")
    return text.replace(old, new, 1)


def patch_voice_service(text: str) -> str:
    text = replace_once(
        text,
        "    -> Gemini TTS -> Linux/PipeWire speaker.\n",
        "    -> local Piper TTS (Gemini optional) -> Linux/PipeWire speaker.\n",
        "voice_service data path",
    )
    text = replace_once(
        text,
        "from .gemini_tts import GeminiTtsClient, GeminiTtsConfig\n",
        "from .tts_provider import build_tts_client, diagnose_tts\n",
        "voice_service TTS import",
    )
    old = '''    groq_key = _setting(project_env, "GROQ_API_KEY")\n    gemini_key = _setting(project_env, "GEMINI_API_KEY")\n    tts_model = _setting(project_env, "R2B4_TTS_MODEL") or "gemini-3.1-flash-tts-preview"\n    tts_voice = _setting(project_env, "R2B4_TTS_VOICE") or "Kore"\n    result: dict[str, object] = {\n        "project_root": str(root),\n        "secret_file": str(root / "conf" / ".wake.env"),\n        "groq_stt_key": "PASS" if groq_key else "FAIL",\n        "llm_provider": provider,\n        "llm_model": model,\n        "llm_api_key": "PASS" if llm_key else "FAIL",\n        "tts_provider": "gemini",\n        "tts_model": tts_model,\n        "tts_voice": tts_voice,\n        "tts_api_key": "PASS" if gemini_key else "FAIL",\n        "action_mode": (_setting(project_env, "R2B4_VOICE_ACTION_MODE") or DEFAULT_ACTION_MODE).lower(),\n        "motor_action_execution": (_setting(project_env, "R2B4_VOICE_ACTION_MODE") or DEFAULT_ACTION_MODE).lower() == "execute",\n        "half_duplex_self_hearing_guard": True,\n    }\n'''
    new = '''    groq_key = _setting(project_env, "GROQ_API_KEY")\n    gemini_key = _setting(project_env, "GEMINI_API_KEY")\n    try:\n        tts_diagnostic = diagnose_tts(root, project_env, gemini_api_key=gemini_key)\n    except Exception as exc:\n        tts_diagnostic = {\n            "tts_provider": _setting(project_env, "R2B4_TTS_PROVIDER") or "piper",\n            "tts_status": "FAIL",\n            "tts_error": f"{type(exc).__name__}: {exc}",\n        }\n    result: dict[str, object] = {\n        "project_root": str(root),\n        "secret_file": str(root / "conf" / ".wake.env"),\n        "groq_stt_key": "PASS" if groq_key else "FAIL",\n        "llm_provider": provider,\n        "llm_model": model,\n        "llm_api_key": "PASS" if llm_key else "FAIL",\n        **tts_diagnostic,\n        "action_mode": (_setting(project_env, "R2B4_VOICE_ACTION_MODE") or DEFAULT_ACTION_MODE).lower(),\n        "motor_action_execution": (_setting(project_env, "R2B4_VOICE_ACTION_MODE") or DEFAULT_ACTION_MODE).lower() == "execute",\n        "half_duplex_self_hearing_guard": True,\n    }\n'''
    text = replace_once(text, old, new, "voice_service diagnostics")
    text = replace_once(
        text,
        '''            groq_key,\n            llm_key,\n            gemini_key,\n            isinstance(result["microphone"], dict) and result["microphone"].get("status") == "PASS",\n''',
        '''            groq_key,\n            llm_key,\n            tts_diagnostic.get("tts_status") == "PASS",\n            isinstance(result["microphone"], dict) and result["microphone"].get("status") == "PASS",\n''',
        "voice_service diagnostic success gate",
    )
    old = '''        if not gemini_key:\n            raise RuntimeError("GEMINI_API_KEY is required for Gemini TTS")\n        transcriber = GroqWakeTranscriber(api_key=groq_key)\n        tts = GeminiTtsClient(\n            api_key=gemini_key,\n            config=GeminiTtsConfig(\n                model=_setting(project_env, "R2B4_TTS_MODEL") or "gemini-3.1-flash-tts-preview",\n                voice=_setting(project_env, "R2B4_TTS_VOICE") or "Kore",\n            ),\n        )\n'''
    new = '''        transcriber = GroqWakeTranscriber(api_key=groq_key)\n        tts = build_tts_client(\n            root,\n            project_env,\n            gemini_api_key=gemini_key,\n        )\n'''
    text = replace_once(text, old, new, "voice_service production TTS wiring")
    return text


def patch_er2_speech(text: str) -> str:
    text = replace_once(
        text,
        "the existing Gemini TTS adapter and Linux PCM/WAV playback path.\n",
        "the shared local-first TTS adapter and Linux PCM/WAV playback path.\n",
        "ER2 speech docstring",
    )
    text = replace_once(
        text,
        "from r2b4_voice.gemini_tts import GeminiTtsClient\n",
        "from r2b4_voice.tts_provider import build_tts_client\n",
        "ER2 speech TTS import",
    )
    text = replace_once(
        text,
        "from .config import api_key_from_env\n",
        "",
        "ER2 speech api_key import",
    )
    text = replace_once(
        text,
        "        self.tts = tts if tts is not None else GeminiTtsClient(api_key=api_key or api_key_from_env())\n",
        "        self.tts = tts if tts is not None else build_tts_client(gemini_api_key=api_key)\n",
        "ER2 speech default TTS wiring",
    )
    return text


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default="/home/alba/project_r2b4")
    parser.add_argument("--skip-tests", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).expanduser().resolve()
    package_root = Path(__file__).resolve().parent

    if not (root / ".git").exists():
        raise SystemExit(f"ERROR: not a git working tree: {root}")

    for rel, expected in EXPECTED_BLOBS.items():
        path = root / rel
        if not path.is_file():
            raise SystemExit(f"ERROR: required source file missing: {rel}")
        actual = git_blob(root, rel)
        if actual != expected:
            raise SystemExit(
                f"ERROR: {rel} has local/newer content (blob {actual}, expected {expected}). "
                "Nothing was changed; refresh the upgrade against the current repo instead of overwriting it."
            )

    for rel in NEW_FILES:
        dest = root / rel
        if dest.exists():
            raise SystemExit(f"ERROR: target already exists; refusing to overwrite: {rel}")

    stamp = time.strftime("%Y%m%d_%H%M%S")
    backup = root / "runtime" / "upgrade_backups" / f"local_tts_{stamp}"
    backup.mkdir(parents=True, exist_ok=False)
    created: list[Path] = []
    touched = [root / rel for rel in EXPECTED_BLOBS]

    for path in touched:
        rel = path.relative_to(root)
        target = backup / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)

    try:
        voice_path = root / "r2b4_voice" / "voice_service.py"
        voice_path.write_text(patch_voice_service(voice_path.read_text(encoding="utf-8")), encoding="utf-8")
        speech_path = root / "r2b4_er2" / "speech.py"
        speech_path.write_text(patch_er2_speech(speech_path.read_text(encoding="utf-8")), encoding="utf-8")

        for rel in NEW_FILES:
            src = package_root / "files" / rel
            dest = root / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
            created.append(dest)

        compile_targets = [
            "r2b4_voice/piper_tts.py",
            "r2b4_voice/tts_provider.py",
            "r2b4_voice/voice_service.py",
            "r2b4_er2/speech.py",
        ]
        result = run([sys.executable, "-m", "py_compile", *compile_targets], cwd=root, check=False)
        if result.returncode != 0:
            raise RuntimeError("py_compile failed:\n" + result.stderr)

        if not args.skip_tests:
            tests = [
                "tests/feature/test_local_tts_provider.py",
                "tests/feature/test_er2_local_tts_wiring.py",
                "tests/feature/test_er2_p0r2.py",
                "tests/feature/test_er2_launcher_stream_cli.py",
            ]
            result = run([sys.executable, "-m", "pytest", "-q", *tests], cwd=root, check=False)
            if result.returncode != 0:
                raise RuntimeError("focused pytest failed:\n" + result.stdout + result.stderr)
            print(result.stdout.strip())

        print(f"PASS: local Piper TTS source upgrade applied to {root}")
        print(f"backup: {backup}")
        print("default TTS provider: piper")
        print("optional cloud provider: R2B4_TTS_PROVIDER=gemini")
        return 0
    except Exception as exc:
        for path in touched:
            rel = path.relative_to(root)
            shutil.copy2(backup / rel, path)
        for path in reversed(created):
            try:
                path.unlink()
            except FileNotFoundError:
                pass
        print(f"ERROR: {exc}", file=sys.stderr)
        print("ROLLBACK: source files restored from backup", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
