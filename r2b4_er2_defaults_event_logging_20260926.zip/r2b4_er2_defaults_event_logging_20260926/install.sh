#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-/home/alba/project_r2b4}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "== R2B4 ER2 defaults + event logging upgrade =="
echo "root: $ROOT"
echo "baseline: 2a9df10f9d69819598bd23550ef8513f30c362ae"
python3 "$HERE/apply_upgrade.py" "$ROOT"

echo
echo "Recommended post-install core validation:"
echo "  cd '$ROOT' && ./r test"
echo
echo "ER2 event journal:"
echo "  $ROOT/runtime/hri_events.ndjson"
