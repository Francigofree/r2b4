#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

BASE_COMMIT = "2a9df10f9d69819598bd23550ef8513f30c362ae"
EXPECTED_BLOBS = {
    "v3/launcher_cli.py": "053d6a0b0535fb2885f49c1630285e5702758090",
    "r2b4_er2/cli.py": "c6cd744e703fa907e2f615c47b7d4163ced3b201",
    "r2b4_er2/streaming.py": "04f88a06b2d76ab1ba97b3009b74fbbfd088bf63",
    "r2b4_er2/preview.py": "d825a7ab1aabfc0a56cd564e89117082c4004b2d",
}
NEW_TEST = "tests/feature/test_er2_defaults_and_event_logging.py"


def run(*argv: str, cwd: Path, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(argv, cwd=cwd, text=True, capture_output=True, check=check)


def blob_sha(root: Path, rel: str) -> str:
    cp = run("git", "hash-object", "--", rel, cwd=root)
    return cp.stdout.strip()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one source match, found {count}")
    return text.replace(old, new, 1)


def patch_launcher(text: str) -> str:
    text = replace_once(
        text,
        '            "stream_defaults": ["camera", "tools"],',
        '            "stream_defaults": ["camera", "tools", "speak", "json"],',
        "launcher stream_defaults",
    )
    text = replace_once(
        text,
        '        "  r er2 \\\"TASK\\\" [OPTIONS]        ER2 Streaming shorthand; camera + tools default ON\\n"',
        '        "  r er2 \\\"TASK\\\" [OPTIONS]        ER2 Streaming shorthand; camera + tools + speak + json default ON\\n"',
        "launcher help defaults",
    )
    return text


def patch_cli(text: str) -> str:
    text = replace_once(
        text,
        '        help="live ER2 Streaming robot session; camera and robot tools are enabled by default",',
        '        help="live ER2 Streaming robot session; camera, robot tools, speech and JSON are enabled by default",',
        "stream help",
    )
    old = '''    stream.add_argument(
        "--speak",
        action="store_true",
        help="speak the accumulated ER2 text through the existing TTS/audio path",
    )
    stream.add_argument("--json", action="store_true", help="emit one machine-readable JSON result")'''
    new = '''    stream.add_argument(
        "--speak",
        action="store_true",
        default=True,
        help="speak the accumulated ER2 text through the existing TTS/audio path (enabled by default)",
    )
    stream.add_argument(
        "--json",
        action="store_true",
        default=True,
        help="emit one machine-readable JSON result (enabled by default)",
    )'''
    text = replace_once(text, old, new, "stream speak/json defaults")

    old = '''            result = Er2StreamingClient(
                tools,
                media,
                cfg,
                on_text=on_text,
                evidence=evidence,
            ).run(args.task, duration_s=args.seconds)'''
    new = '''            evidence.emit(
                "ER2_STREAM_CLI_START",
                task_chars=len(args.task.strip()),
                camera_enabled=bool(args.camera),
                tools_enabled=bool(args.tools),
                speak_enabled=bool(args.speak),
                json_enabled=bool(args.json),
                bounded_duration_s=args.seconds,
            )
            result = Er2StreamingClient(
                tools,
                media,
                cfg,
                on_text=on_text,
                evidence=evidence,
            ).run(args.task, duration_s=args.seconds)'''
    text = replace_once(text, old, new, "stream CLI start evidence")

    old = '''            payload = {
                "mode": "stream",
                "text": text,
                "camera": bool(args.camera),
                "tools": bool(args.tools),
                "reconnect_count": result.reconnect_count,
                "resumption": bool(result.latest_resumption_handle),
                "stopped_cleanly": result.stopped_cleanly,
            }
            if args.json:'''
    new = '''            payload = {
                "mode": "stream",
                "text": text,
                "camera": bool(args.camera),
                "tools": bool(args.tools),
                "speak": bool(args.speak),
                "json": bool(args.json),
                "reconnect_count": result.reconnect_count,
                "resumption": bool(result.latest_resumption_handle),
                "stopped_cleanly": result.stopped_cleanly,
            }
            evidence.emit(
                "ER2_STREAM_CLI_COMPLETE",
                output_chars=len(text),
                camera_enabled=bool(args.camera),
                tools_enabled=bool(args.tools),
                speak_enabled=bool(args.speak),
                json_enabled=bool(args.json),
                reconnect_count=result.reconnect_count,
                resumable=bool(result.latest_resumption_handle),
                stopped_cleanly=result.stopped_cleanly,
            )
            if args.json:'''
    text = replace_once(text, old, new, "stream CLI complete evidence")
    return text


def patch_streaming(text: str) -> str:
    old = '''                                await session.send_client_content(
                                    turns=types.Content(
                                        role="user",
                                        parts=[
                                            types.Part(inline_data=types.Blob(data=frame, mime_type="image/jpeg")),
                                            types.Part(text=initial_task),
                                        ],
                                    ),
                                    turn_complete=True,
                                )
                                first_connection = False'''
    new = '''                                await session.send_client_content(
                                    turns=types.Content(
                                        role="user",
                                        parts=[
                                            types.Part(inline_data=types.Blob(data=frame, mime_type="image/jpeg")),
                                            types.Part(text=initial_task),
                                        ],
                                    ),
                                    turn_complete=True,
                                )
                                self._emit(
                                    "ER2_STREAM_INITIAL_TURN_TX",
                                    task_chars=len(initial_task),
                                    frame_bytes=len(frame),
                                    turn_complete=True,
                                )
                                first_connection = False'''
    text = replace_once(text, old, new, "stream initial turn TX")

    old = '''                        if isinstance(text, str) and text:
                            self._on_text(text)'''
    new = '''                        if isinstance(text, str) and text:
                            self._emit("ER2_STREAM_TEXT_RX", chars=len(text))
                            self._on_text(text)'''
    text = replace_once(text, old, new, "stream text RX")

    old = '''                    if getattr(server_content, "turn_complete", False):
                        completed_turn = True
                        turn_done.set()'''
    new = '''                    if getattr(server_content, "turn_complete", False):
                        self._emit("ER2_STREAM_TURN_COMPLETE_RX")
                        completed_turn = True
                        turn_done.set()'''
    text = replace_once(text, old, new, "stream turn complete RX")

    old = '''                        name = getattr(call, "name", None)
                        args = getattr(call, "args", {}) or {}
                        call_id = getattr(call, "id", None)
                        if not isinstance(name, str) or not isinstance(args, Mapping):'''
    new = '''                        name = getattr(call, "name", None)
                        args = getattr(call, "args", {}) or {}
                        call_id = getattr(call, "id", None)
                        self._emit(
                            "ER2_STREAM_TOOL_CALL_RX",
                            tool_name=name if isinstance(name, str) else None,
                            call_id=call_id if isinstance(call_id, str) else None,
                            argument_count=len(args) if isinstance(args, Mapping) else None,
                            physical=isinstance(name, str) and name in PHYSICAL_TOOLS,
                        )
                        if not isinstance(name, str) or not isinstance(args, Mapping):'''
    text = replace_once(text, old, new, "stream tool call RX")

    old = '''                    if responses:
                        await session.send_tool_response(function_responses=responses)'''
    new = '''                    if responses:
                        await session.send_tool_response(function_responses=responses)
                        self._emit("ER2_STREAM_TOOL_RESPONSE_TX", response_count=len(responses))'''
    text = replace_once(text, old, new, "stream tool response TX")

    old = '''            await session.send_realtime_input(
                text=(
                    "[R2B4 HEARTBEAT] Observe the latest frame and robot status. "
                    "Continue the active task only through declared blocking tools. "
                    "If no movement is needed, do not invent one. Robot status: "
                    + _compact(status)
                )
            )
            await turn_done.wait()'''
    new = '''            await session.send_realtime_input(
                text=(
                    "[R2B4 HEARTBEAT] Observe the latest frame and robot status. "
                    "Continue the active task only through declared blocking tools. "
                    "If no movement is needed, do not invent one. Robot status: "
                    + _compact(status)
                )
            )
            self._emit(
                "ER2_STREAM_HEARTBEAT_TX",
                frame_bytes=len(frame),
                status_chars=len(_compact(status)),
            )
            await turn_done.wait()'''
    text = replace_once(text, old, new, "stream heartbeat TX")
    return text


def patch_preview(text: str) -> str:
    old = '''        try:
            interaction = self.client.interactions.create(**kwargs)  # type: ignore[attr-defined]
            rounds = 0'''
    new = '''        try:
            self._emit(
                "ER2_PREVIEW_REQUEST_TX",
                model=self.config.preview_model,
                input_items=len(inputs),
                image_bytes=len(image_bytes) if image_bytes is not None else 0,
                tool_declarations=len(tool_declarations or ()),
            )
            interaction = self.client.interactions.create(**kwargs)  # type: ignore[attr-defined]
            steps = _interaction_steps(interaction)
            self._emit(
                "ER2_PREVIEW_RESPONSE_RX",
                model=self.config.preview_model,
                interaction_id=getattr(interaction, "id", None),
                step_count=len(steps),
                function_call_count=sum(1 for step in steps if getattr(step, "type", None) == "function_call"),
            )
            rounds = 0'''
    text = replace_once(text, old, new, "preview request/response evidence")

    old = '''                    if not isinstance(name, str) or arguments is None or not isinstance(call_id, str) or not call_id:
                        raise Er2PreviewError("ER2 returned malformed function call")
                    if name in PHYSICAL_TOOLS and physical_tool_executed:'''
    new = '''                    if not isinstance(name, str) or arguments is None or not isinstance(call_id, str) or not call_id:
                        raise Er2PreviewError("ER2 returned malformed function call")
                    self._emit(
                        "ER2_PREVIEW_TOOL_CALL_RX",
                        interaction_id=previous_id,
                        tool_name=name,
                        call_id=call_id,
                        argument_count=len(arguments),
                        physical=name in PHYSICAL_TOOLS,
                    )
                    if name in PHYSICAL_TOOLS and physical_tool_executed:'''
    text = replace_once(text, old, new, "preview tool call RX")

    old = '''                rounds += 1
                # tools and generation_config are interaction-scoped in the
                # Interactions API, so they must be re-specified on every turn.
                interaction = self.client.interactions.create(  # type: ignore[attr-defined]
                    model=self.config.preview_model,
                    previous_interaction_id=previous_id,
                    input=function_results,
                    tools=tool_declarations,
                    generation_config=generation_config,
                )

            text = getattr(interaction, "output_text", None)'''
    new = '''                rounds += 1
                # tools and generation_config are interaction-scoped in the
                # Interactions API, so they must be re-specified on every turn.
                self._emit(
                    "ER2_PREVIEW_TOOL_RESULTS_TX",
                    previous_interaction_id=previous_id,
                    tool_round=rounds,
                    result_count=len(function_results),
                )
                interaction = self.client.interactions.create(  # type: ignore[attr-defined]
                    model=self.config.preview_model,
                    previous_interaction_id=previous_id,
                    input=function_results,
                    tools=tool_declarations,
                    generation_config=generation_config,
                )
                steps = _interaction_steps(interaction)
                self._emit(
                    "ER2_PREVIEW_RESPONSE_RX",
                    model=self.config.preview_model,
                    interaction_id=getattr(interaction, "id", None),
                    step_count=len(steps),
                    function_call_count=sum(1 for step in steps if getattr(step, "type", None) == "function_call"),
                )

            text = getattr(interaction, "output_text", None)'''
    text = replace_once(text, old, new, "preview tool results TX/follow-up RX")
    return text


PATCHERS = {
    "v3/launcher_cli.py": patch_launcher,
    "r2b4_er2/cli.py": patch_cli,
    "r2b4_er2/streaming.py": patch_streaming,
    "r2b4_er2/preview.py": patch_preview,
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default="/home/alba/project_r2b4")
    parser.add_argument("--skip-tests", action="store_true")
    ns = parser.parse_args()
    root = Path(ns.root).expanduser().resolve()
    payload_root = Path(__file__).resolve().parent / "files"
    if not (root / ".git").exists():
        raise SystemExit(f"ERROR: not a git working tree: {root}")

    for rel, expected in EXPECTED_BLOBS.items():
        path = root / rel
        if not path.is_file():
            raise SystemExit(f"ERROR: missing source file: {rel}")
        actual = blob_sha(root, rel)
        if actual != expected:
            raise SystemExit(
                f"ERROR: source changed: {rel}\n"
                f" expected blob: {expected}\n actual blob:   {actual}\n"
                f"Package baseline is {BASE_COMMIT}; regenerate source-first instead of overwriting local changes."
            )

    new_test = root / NEW_TEST
    if new_test.exists():
        raise SystemExit(f"ERROR: target test already exists: {NEW_TEST}")

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = root / ".upgrade_backups" / f"er2_defaults_event_logging_{stamp}"
    backup.mkdir(parents=True, exist_ok=False)
    created: list[Path] = []
    try:
        for rel in EXPECTED_BLOBS:
            src = root / rel
            dst = backup / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)

        for rel, patcher in PATCHERS.items():
            path = root / rel
            original = path.read_text(encoding="utf-8")
            updated = patcher(original)
            path.write_text(updated, encoding="utf-8")

        new_test.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(payload_root / NEW_TEST, new_test)
        created.append(new_test)

        compile_targets = [root / rel for rel in PATCHERS] + [new_test]
        for target in compile_targets:
            compile(target.read_text(encoding="utf-8"), str(target), "exec")

        if not ns.skip_tests:
            test_env = dict(__import__("os").environ)
            test_env["PYTHONDONTWRITEBYTECODE"] = "1"
            focused = subprocess.run(
                [
                    sys.executable, "-m", "pytest", "-q",
                    NEW_TEST,
                    "tests/feature/test_er2_launcher_stream_cli.py",
                    "tests/feature/test_er2_p0r2.py",
                ],
                cwd=root,
                env=test_env,
            )
            if focused.returncode != 0:
                raise RuntimeError("focused pytest failed")

        print(f"PASS: ER2 defaults + event logging upgrade applied")
        print(f"baseline: {BASE_COMMIT}")
        print(f"backup: {backup}")
        print("default r er2 stream capabilities: camera=ON tools=ON speak=ON json=ON")
        print("event journal: runtime/hri_events.ndjson")
        return 0
    except Exception as exc:
        for rel in EXPECTED_BLOBS:
            saved = backup / rel
            if saved.is_file():
                shutil.copy2(saved, root / rel)
        for path in created:
            try:
                path.unlink()
            except FileNotFoundError:
                pass
        print(f"ROLLBACK: source files restored from {backup}", file=sys.stderr)
        raise SystemExit(f"ERROR: {exc}")


if __name__ == "__main__":
    raise SystemExit(main())
