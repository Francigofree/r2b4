# R2B4 ER2 default capabilities + event-driven communication logging

Source baseline: `Francigofree/r2b4` main commit
`2a9df10f9d69819598bd23550ef8513f30c362ae`.

## Változás

A shorthand:

```bash
./r er2 "..."
```

marad canonical ER2 Streaming hívás, de a stream négy capability-je alapból ON:

- camera
- tools
- speak
- json

Az explicit `--camera --tools --speak --json` formák továbbra is elfogadottak.

## Eseményvezérelt ER2 communication evidence

Nem készül új logging framework. A meglévő append-only, bounded HRI journal használatos:

```text
runtime/hri_events.ndjson
```

Új metadata-only események többek között:

- `ER2_STREAM_CLI_START`
- `ER2_STREAM_INITIAL_TURN_TX`
- `ER2_STREAM_TEXT_RX`
- `ER2_STREAM_TURN_COMPLETE_RX`
- `ER2_STREAM_TOOL_CALL_RX`
- `ER2_STREAM_TOOL_RESPONSE_TX`
- `ER2_STREAM_HEARTBEAT_TX`
- `ER2_STREAM_CLI_COMPLETE`
- `ER2_PREVIEW_REQUEST_TX`
- `ER2_PREVIEW_RESPONSE_RX`
- `ER2_PREVIEW_TOOL_CALL_RX`
- `ER2_PREVIEW_TOOL_RESULTS_TX`

A meglévő connect/reconnect/go-away/error/complete és `ER2_TOOL_CALL/RESULT/ERROR`
events változatlanul megmaradnak.

A kommunikáció teljes prompt- és válaszszövege nincs duplikálva a journalba. Az új események
csak korrelációs/metaadat mezőket írnak (karakterszám, frame byte, tool név/id, státusz stb.).

## Telepítés

```bash
cd /home/alba/project_r2b4
unzip -o r2b4_er2_defaults_event_logging_20260926.zip -d /tmp
/tmp/r2b4_er2_defaults_event_logging_20260926/install.sh /home/alba/project_r2b4
```

Az installer az érintett source-fájlok Git blob SHA-ját ellenőrzi. Eltérés esetén nem írja felül
a lokális módosítást. A módosítás előtt source backup készül `.upgrade_backups/` alatt.

Célzott pytest automatikusan lefut; hibánál automatikus source rollback történik.

## Ellenőrzés

```bash
./r er2 "Mondd el röviden, mit látsz."
```

A bare hívás most JSON kimenetet ad és a választ ki is mondja; camera és tools szintén ON.

Log:

```bash
tail -n 50 runtime/hri_events.ndjson
```

CORE regresszió:

```bash
./r test
```
