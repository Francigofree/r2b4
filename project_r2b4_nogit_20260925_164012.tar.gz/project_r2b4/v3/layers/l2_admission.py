"""L2 freshness, ordering and source-health admission."""

from __future__ import annotations

from dataclasses import dataclass

from v3.contracts import (
    AcquisitionFrame,
    AdmittedFrame,
    DeviceHealthState,
    Observation,
    RejectedObservation,
    RejectionReason,
)


@dataclass(frozen=True, slots=True)
class AdmissionConfig:
    """Immutable time-alignment limits injected into the L2 state owner."""

    max_sample_age_ns: int
    max_future_skew_ns: int = 0

    def __post_init__(self) -> None:
        for name in ("max_sample_age_ns", "max_future_skew_ns"):
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                raise ValueError(f"{name} must be a non-negative integer")


@dataclass(frozen=True, slots=True)
class AdmissionStateCheckpoint:
    last_sequences: tuple[tuple[str, str, int], ...]

    def __post_init__(self) -> None:
        for device_id, kind, sequence in self.last_sequences:
            if not device_id or not kind or sequence < 0:
                raise ValueError("admission checkpoint contains an invalid sequence")


class InputAdmission:
    """Own per-source sequence history and close L2 admission deterministically."""

    __slots__ = ("_config", "_last_sequences")

    def __init__(self, config: AdmissionConfig) -> None:
        self._config = config
        self._last_sequences: dict[tuple[str, str], int] = {}

    def checkpoint(self) -> AdmissionStateCheckpoint:
        return AdmissionStateCheckpoint(
            tuple(
                (device_id, kind, sequence)
                for (device_id, kind), sequence in sorted(self._last_sequences.items())
            )
        )

    def restore(self, checkpoint: AdmissionStateCheckpoint) -> None:
        if not isinstance(checkpoint, AdmissionStateCheckpoint):
            raise TypeError("checkpoint must be AdmissionStateCheckpoint")
        self._last_sequences = {
            (device_id, kind): sequence
            for device_id, kind, sequence in checkpoint.last_sequences
        }

    def __call__(self, frame: AcquisitionFrame) -> AdmittedFrame:
        health_by_device = {item.device_id: item.state for item in frame.io_health}
        degraded = {
            item.device_id
            for item in frame.io_health
            if item.state is not DeviceHealthState.OK
        }
        accepted: list[Observation] = []
        rejected: list[RejectedObservation] = []
        rejection_keys: set[tuple[str, int, RejectionReason]] = set()

        for sample in frame.samples:
            key = (sample.device_id, sample.kind)
            previous_sequence = self._last_sequences.get(key)
            reason: RejectionReason | None = None
            age_ns = max(0, frame.context.monotonic_ns - sample.captured_monotonic_ns)
            values = {field.key: field.value for field in sample.values}
            measurement_timing_valid = values.get("measurement_timing_valid", True)
            measurement_stale = values.get("measurement_stale", False)
            for value, name in (
                (measurement_timing_valid, "measurement_timing_valid"),
                (measurement_stale, "measurement_stale"),
            ):
                if type(value) is not bool:
                    raise ValueError(f"{sample.kind}.{name} must be bool")
            if not measurement_timing_valid or measurement_stale:
                degraded.add(sample.device_id)

            if not measurement_timing_valid:
                reason = RejectionReason.TIME_ALIGNMENT_FAILED
            elif measurement_stale or age_ns > self._config.max_sample_age_ns:
                reason = RejectionReason.STALE
            elif previous_sequence is not None and sample.sequence == previous_sequence:
                reason = RejectionReason.DUPLICATE
            elif previous_sequence is not None and sample.sequence < previous_sequence:
                reason = RejectionReason.OUT_OF_ORDER
            elif (
                sample.captured_monotonic_ns
                > frame.context.monotonic_ns + self._config.max_future_skew_ns
            ):
                reason = RejectionReason.TIME_ALIGNMENT_FAILED
            elif health_by_device.get(sample.device_id) in {
                None,
                DeviceHealthState.FAILED,
                DeviceHealthState.UNKNOWN,
            }:
                degraded.add(sample.device_id)
                reason = RejectionReason.UNTRUSTED

            if (
                reason is not RejectionReason.TIME_ALIGNMENT_FAILED
                and (previous_sequence is None or sample.sequence > previous_sequence)
            ):
                self._last_sequences[key] = sample.sequence

            if reason is not None:
                rejection_key = (sample.device_id, sample.sequence, reason)
                if rejection_key not in rejection_keys:
                    rejected.append(
                        RejectedObservation(
                            source_device_id=sample.device_id,
                            source_sequence=sample.sequence,
                            reason=reason,
                            age_ns=age_ns,
                        )
                    )
                    rejection_keys.add(rejection_key)
                continue
            accepted.append(
                Observation(
                    kind=sample.kind,
                    source_device_id=sample.device_id,
                    source_sequence=sample.sequence,
                    captured_monotonic_ns=sample.captured_monotonic_ns,
                    values=sample.values,
                )
            )

        return AdmittedFrame(
            frame.context,
            tuple(accepted),
            tuple(rejected),
            tuple(sorted(degraded)),
        )


def admit(frame: AcquisitionFrame) -> AdmittedFrame:
    """Admit a closed fake frame for the STOP-only validation composition."""

    accepted = tuple(
        Observation(
            kind=sample.kind,
            source_device_id=sample.device_id,
            source_sequence=sample.sequence,
            captured_monotonic_ns=sample.captured_monotonic_ns,
            values=sample.values,
        )
        for sample in frame.samples
    )
    degraded = tuple(
        health.device_id
        for health in frame.io_health
        if health.state is not DeviceHealthState.OK
    )
    return AdmittedFrame(frame.context, accepted, (), degraded)


__all__ = ["AdmissionConfig", "AdmissionStateCheckpoint", "InputAdmission", "admit"]
