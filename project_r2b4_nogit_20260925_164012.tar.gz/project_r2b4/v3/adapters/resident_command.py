"""Strict local command mailbox for the resident native V3 process."""

from __future__ import annotations

import hashlib
import json
import math
import os
import stat
import threading
import time
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from v3.contracts import CommandMode, CommandRequest, DataField, TickContext
from v3.contracts.base import require_token
from v3.runtime_performance import temporary_current_affinity


RESIDENT_COMMAND_SCHEMA = "R2B4_V3_RESIDENT_COMMAND_V2"


def _positive_int(value: object, name: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return value


def _nonnegative_int(value: object, name: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer")
    return value


def _finite(value: object, name: str) -> float:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
    ):
        raise ValueError(f"{name} must be finite numeric")
    return float(value)


@dataclass(frozen=True, slots=True)
class ResidentCommandMailboxConfig:
    """Filesystem trust, time and initial motion limits for one mailbox."""

    path: Path
    maximum_ttl_ns: int = 250_000_000
    maximum_future_skew_ns: int = 5_000_000
    maximum_linear_speed_mps: float = 0.50
    maximum_angular_speed_rad_s: float = 1.20
    maximum_file_bytes: int = 4096
    expected_uid: int = -1

    def __post_init__(self) -> None:
        path = Path(self.path)
        if not path.is_absolute():
            raise ValueError("path must be absolute")
        object.__setattr__(self, "path", path)
        _positive_int(self.maximum_ttl_ns, "maximum_ttl_ns")
        _nonnegative_int(self.maximum_future_skew_ns, "maximum_future_skew_ns")
        if self.maximum_future_skew_ns > self.maximum_ttl_ns:
            raise ValueError("maximum_future_skew_ns cannot exceed maximum_ttl_ns")
        for value, name in (
            (self.maximum_linear_speed_mps, "maximum_linear_speed_mps"),
            (self.maximum_angular_speed_rad_s, "maximum_angular_speed_rad_s"),
        ):
            if _finite(value, name) <= 0.0:
                raise ValueError(f"{name} must be positive")
        _positive_int(self.maximum_file_bytes, "maximum_file_bytes")
        expected_uid = self.expected_uid
        if expected_uid == -1:
            object.__setattr__(self, "expected_uid", os.geteuid())
        else:
            _nonnegative_int(expected_uid, "expected_uid")


class AtomicResidentCommandGateway:
    """Read one immutable local command revision per V3 tick.

    A missing mailbox means STOP. Malformed, untrusted, rewritten or regressed
    revisions raise and therefore become one canonical CommandGateway fault
    tick. Repeating the same immutable revision is allowed until its monotonic
    expiry, after which it deterministically becomes STOP.
    """

    __slots__ = (
        "_config",
        "_last_digest",
        "_last_revision",
        "_monotonic_ns",
        "_requires_new_revision",
    )

    def __init__(
        self,
        config: ResidentCommandMailboxConfig,
        *,
        monotonic_ns: Callable[[], int] = time.monotonic_ns,
    ) -> None:
        if not isinstance(config, ResidentCommandMailboxConfig):
            raise TypeError("config must be ResidentCommandMailboxConfig")
        if not callable(monotonic_ns):
            raise TypeError("monotonic_ns must be callable")
        self._config = config
        self._monotonic_ns = monotonic_ns
        self._last_revision: int | None = None
        self._last_digest: str | None = None
        self._requires_new_revision = False

    @property
    def last_revision(self) -> int | None:
        return self._last_revision

    @staticmethod
    def _stop(context: TickContext, reason: str) -> CommandRequest:
        return CommandRequest(
            context=context,
            command_id=f"resident.mailbox.{reason}.{context.tick_id}",
            mode=CommandMode.STOP,
            goal=(),
            expiry_tick=context.tick_id,
        )

    def _read_trusted_bytes(self) -> bytes | None:
        path = self._config.path
        flags = (os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
                 | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
        try:
            descriptor = os.open(path, flags)
        except FileNotFoundError:
            return None
        except OSError as exc:
            raise ValueError("command mailbox cannot be opened safely") from exc
        try:
            metadata = os.fstat(descriptor)
            if not stat.S_ISREG(metadata.st_mode):
                raise ValueError("command mailbox must be a regular file")
            if metadata.st_uid != self._config.expected_uid:
                raise ValueError("command mailbox owner is not trusted")
            if stat.S_IMODE(metadata.st_mode) & 0o022:
                raise ValueError("command mailbox must not be group/world writable")
            if metadata.st_size > self._config.maximum_file_bytes:
                raise ValueError("command mailbox exceeds maximum_file_bytes")
            chunks: list[bytes] = []
            total = 0
            while True:
                chunk = os.read(descriptor, min(4096, self._config.maximum_file_bytes + 1 - total))
                if not chunk:
                    break
                chunks.append(chunk)
                total += len(chunk)
                if total > self._config.maximum_file_bytes:
                    raise ValueError("command mailbox exceeds maximum_file_bytes")
            return b"".join(chunks)
        finally:
            os.close(descriptor)

    def snapshot(self, context: TickContext) -> CommandRequest:
        if not isinstance(context, TickContext):
            raise TypeError("context must be TickContext")
        raw = self._read_trusted_bytes()
        if raw is None:
            if self._last_revision is not None:
                self._requires_new_revision = True
            return self._stop(context, "missing")
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError("command mailbox must contain valid UTF-8 JSON") from exc
        if not isinstance(payload, dict):
            raise ValueError("command mailbox root must be an object")
        if payload.get("schema") != RESIDENT_COMMAND_SCHEMA:
            raise ValueError("command mailbox schema is invalid")

        # Command issue/expiry belongs to the external ingress observation
        # boundary.  A TickContext may be older after a blocking L0 read, so it
        # must not be used as the wall-time authority for mailbox freshness.
        observed_ns = _nonnegative_int(
            self._monotonic_ns(),
            "observed_monotonic_ns",
        )

        mode_value = payload.get("mode")
        try:
            mode = CommandMode(mode_value)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                "command mode must be STOP, TELEOP, EXPLORE, FACE_PERSON or FOLLOW_PERSON"
            ) from exc
        if mode not in (
            CommandMode.STOP,
            CommandMode.TELEOP,
            CommandMode.EXPLORE,
            CommandMode.FACE_PERSON,
            CommandMode.FOLLOW_PERSON,
        ):
            raise ValueError(
                "command mode must be STOP, TELEOP, EXPLORE, FACE_PERSON or FOLLOW_PERSON"
            )
        common_keys = {
            "schema",
            "revision",
            "command_id",
            "issued_monotonic_ns",
            "expires_monotonic_ns",
            "mode",
        }
        limit_keys = {"max_v_mps", "max_omega_rad_s"}
        motion_keys = {"v_mps", "omega_rad_s"} | limit_keys
        expected_keys = common_keys | (
            motion_keys
            if mode is CommandMode.TELEOP
            else limit_keys
            if mode in (CommandMode.EXPLORE, CommandMode.FOLLOW_PERSON)
            else {"max_omega_rad_s"}
            if mode is CommandMode.FACE_PERSON
            else set()
        )
        if set(payload) != expected_keys:
            raise ValueError("command mailbox fields do not match its mode")

        revision = _positive_int(payload.get("revision"), "revision")
        command_id = payload.get("command_id")
        require_token(command_id, "command_id")
        issued_ns = _nonnegative_int(payload.get("issued_monotonic_ns"), "issued_monotonic_ns")
        expires_ns = _nonnegative_int(payload.get("expires_monotonic_ns"), "expires_monotonic_ns")
        if expires_ns < issued_ns:
            raise ValueError("command expiry cannot precede issue time")
        if expires_ns - issued_ns > self._config.maximum_ttl_ns:
            raise ValueError("command TTL exceeds maximum_ttl_ns")
        if issued_ns > observed_ns + self._config.maximum_future_skew_ns:
            raise ValueError("command issue time is in the future")

        digest = hashlib.sha256(raw).hexdigest()
        if self._last_revision is not None:
            if self._requires_new_revision and revision <= self._last_revision:
                raise ValueError("command revision must advance after mailbox removal")
            if revision < self._last_revision:
                raise ValueError("command revision regressed")
            if revision == self._last_revision and digest != self._last_digest:
                raise ValueError("command revision was rewritten")
        if self._last_revision is None or revision > self._last_revision:
            self._last_revision = revision
            self._last_digest = digest
            self._requires_new_revision = False

        if observed_ns > expires_ns:
            return self._stop(context, f"expired.{revision}")
        if mode is CommandMode.STOP:
            return CommandRequest(
                context=context,
                command_id=command_id,
                mode=CommandMode.STOP,
                goal=(),
                expiry_tick=context.tick_id,
            )

        max_omega_rad_s = _finite(payload.get("max_omega_rad_s"), "max_omega_rad_s")
        if not 0.0 < max_omega_rad_s <= self._config.maximum_angular_speed_rad_s:
            raise ValueError("max_omega_rad_s exceeds the resident process limit")
        if mode is CommandMode.FACE_PERSON:
            return CommandRequest(
                context=context,
                command_id=command_id,
                mode=CommandMode.FACE_PERSON,
                goal=(DataField("max_omega_rad_s", max_omega_rad_s),),
                expiry_tick=context.tick_id,
            )

        max_v_mps = _finite(payload.get("max_v_mps"), "max_v_mps")
        if not 0.0 < max_v_mps <= self._config.maximum_linear_speed_mps:
            raise ValueError("max_v_mps exceeds the resident process limit")
        if mode in (CommandMode.EXPLORE, CommandMode.FOLLOW_PERSON):
            return CommandRequest(
                context=context,
                command_id=command_id,
                mode=mode,
                goal=(
                    DataField("max_v_mps", max_v_mps),
                    DataField("max_omega_rad_s", max_omega_rad_s),
                ),
                expiry_tick=context.tick_id,
            )

        v_mps = _finite(payload.get("v_mps"), "v_mps")
        omega_rad_s = _finite(payload.get("omega_rad_s"), "omega_rad_s")
        if abs(v_mps) > max_v_mps or abs(omega_rad_s) > max_omega_rad_s:
            raise ValueError("command target exceeds its declared limit")
        return CommandRequest(
            context=context,
            command_id=command_id,
            mode=CommandMode.TELEOP,
            goal=(
                DataField("v_mps", v_mps),
                DataField("omega_rad_s", omega_rad_s),
                DataField("max_v_mps", max_v_mps),
                DataField("max_omega_rad_s", max_omega_rad_s),
            ),
            expiry_tick=context.tick_id,
        )


class AsyncResidentCommandGateway(AtomicResidentCommandGateway):
    """Acquire trusted immutable mailbox bytes outside the tick.

    The inherited gateway still owns revision, digest, limits and TTL validation.
    A stalled reader cannot refresh command expiry, and a read failure is sticky.
    """

    def __init__(self, config: ResidentCommandMailboxConfig, *,
                 monotonic_ns: Callable[[], int] = time.monotonic_ns,
                 worker_cpu: int | None = None, strict_affinity: bool = False) -> None:
        super().__init__(config, monotonic_ns=monotonic_ns)
        self._worker_cpu = worker_cpu
        self._strict_affinity = strict_affinity
        self._mailbox: bytes | None = None
        self._read_error: Exception | None = None
        self._stop_reader = threading.Event()
        self._reader: threading.Thread | None = None

    def start(self) -> None:
        if self._reader is not None:
            raise RuntimeError("command reader already started")
        self._reader = threading.Thread(
            target=self._acquire, name="r2b4-command", daemon=True
        )
        with temporary_current_affinity(
            self._worker_cpu, role="command", strict=self._strict_affinity
        ):
            self._reader.start()

    def _acquire(self) -> None:
        try:
            while not self._stop_reader.is_set():
                self._mailbox = super()._read_trusted_bytes()
                self._stop_reader.wait(0.005)
        except Exception as exc:
            self._read_error = exc

    def _read_trusted_bytes(self) -> bytes | None:
        if self._read_error is not None:
            raise ValueError("asynchronous command mailbox read failed") from self._read_error
        if self._reader is None or self._stop_reader.is_set():
            return None
        return self._mailbox

    def close(self) -> None:
        self._stop_reader.set()
        if self._reader is not None:
            self._reader.join(timeout=1.0)
            if self._reader.is_alive():
                raise RuntimeError("command mailbox reader did not stop")


class ResidentCommandClient:
    """Atomically publish heartbeat revisions for one logical resident command.

    This edge client only serializes the mailbox contract. The resident gateway
    remains responsible for trust, TTL and process-limit enforcement, while the
    canonical L5-L12 path remains the sole control authority.
    """

    __slots__ = ("_config", "_monotonic_ns", "_revision")

    def __init__(
        self,
        config: ResidentCommandMailboxConfig,
        *,
        monotonic_ns: Callable[[], int] = time.monotonic_ns,
    ) -> None:
        if not isinstance(config, ResidentCommandMailboxConfig):
            raise TypeError("config must be ResidentCommandMailboxConfig")
        if not callable(monotonic_ns):
            raise TypeError("monotonic_ns must be callable")
        self._config = config
        self._monotonic_ns = monotonic_ns
        self._revision: int | None = None

    @property
    def last_revision(self) -> int | None:
        return self._revision

    def publish_stop(self, command_id: str, *, ttl_ns: int) -> int:
        return self._publish(command_id, CommandMode.STOP, {}, ttl_ns)

    def publish_teleop(
        self,
        command_id: str,
        *,
        v_mps: float,
        omega_rad_s: float,
        max_v_mps: float,
        max_omega_rad_s: float,
        ttl_ns: int,
    ) -> int:
        return self._publish(
            command_id,
            CommandMode.TELEOP,
            {
                "v_mps": v_mps,
                "omega_rad_s": omega_rad_s,
                "max_v_mps": max_v_mps,
                "max_omega_rad_s": max_omega_rad_s,
            },
            ttl_ns,
        )

    def publish_explore(
        self,
        command_id: str,
        *,
        max_v_mps: float,
        max_omega_rad_s: float,
        ttl_ns: int,
    ) -> int:
        return self._publish(
            command_id,
            CommandMode.EXPLORE,
            {
                "max_v_mps": max_v_mps,
                "max_omega_rad_s": max_omega_rad_s,
            },
            ttl_ns,
        )

    def publish_face_person(
        self,
        command_id: str,
        *,
        max_omega_rad_s: float,
        ttl_ns: int,
    ) -> int:
        return self._publish(
            command_id,
            CommandMode.FACE_PERSON,
            {"max_omega_rad_s": max_omega_rad_s},
            ttl_ns,
        )

    def publish_follow_person(
        self,
        command_id: str,
        *,
        max_v_mps: float,
        max_omega_rad_s: float,
        ttl_ns: int,
    ) -> int:
        return self._publish(
            command_id,
            CommandMode.FOLLOW_PERSON,
            {
                "max_v_mps": max_v_mps,
                "max_omega_rad_s": max_omega_rad_s,
            },
            ttl_ns,
        )

    def _publish(
        self,
        command_id: str,
        mode: CommandMode,
        values: Mapping[str, object],
        ttl_ns: int,
    ) -> int:
        require_token(command_id, "command_id")
        if mode not in (
            CommandMode.STOP,
            CommandMode.TELEOP,
            CommandMode.EXPLORE,
            CommandMode.FACE_PERSON,
            CommandMode.FOLLOW_PERSON,
        ):
            raise ValueError(
                "client mode must be STOP, TELEOP, EXPLORE, FACE_PERSON or FOLLOW_PERSON"
            )
        ttl = _positive_int(ttl_ns, "ttl_ns")
        if ttl > self._config.maximum_ttl_ns:
            raise ValueError("command TTL exceeds maximum_ttl_ns")
        normalized = self._validated_values(mode, values)
        if self._revision is None:
            self._revision = self._existing_revision()
        revision = self._revision + 1
        issued_ns = _nonnegative_int(self._monotonic_ns(), "issued_monotonic_ns")
        payload: dict[str, object] = {
            "schema": RESIDENT_COMMAND_SCHEMA,
            "revision": revision,
            "command_id": command_id,
            "issued_monotonic_ns": issued_ns,
            "expires_monotonic_ns": issued_ns + ttl,
            "mode": mode.value,
            **normalized,
        }
        encoded = (json.dumps(payload, sort_keys=True) + "\n").encode("utf-8")
        if len(encoded) > self._config.maximum_file_bytes:
            raise ValueError("command mailbox exceeds maximum_file_bytes")
        self._atomic_write(encoded)
        self._revision = revision
        return revision

    def _validated_values(
        self,
        mode: CommandMode,
        values: Mapping[str, object],
    ) -> dict[str, float]:
        expected = (
            {"v_mps", "omega_rad_s", "max_v_mps", "max_omega_rad_s"}
            if mode is CommandMode.TELEOP
            else {"max_v_mps", "max_omega_rad_s"}
            if mode in (CommandMode.EXPLORE, CommandMode.FOLLOW_PERSON)
            else {"max_omega_rad_s"}
            if mode is CommandMode.FACE_PERSON
            else set()
        )
        if set(values) != expected:
            raise ValueError("client command values do not match its mode")
        normalized = {key: _finite(value, key) for key, value in values.items()}
        if mode is CommandMode.STOP:
            return normalized
        max_omega_rad_s = normalized["max_omega_rad_s"]
        if not 0.0 < max_omega_rad_s <= self._config.maximum_angular_speed_rad_s:
            raise ValueError("max_omega_rad_s exceeds the resident process limit")
        if mode is CommandMode.FACE_PERSON:
            return normalized
        max_v_mps = normalized["max_v_mps"]
        if not 0.0 < max_v_mps <= self._config.maximum_linear_speed_mps:
            raise ValueError("max_v_mps exceeds the resident process limit")
        if mode is CommandMode.TELEOP and (
            abs(normalized["v_mps"]) > max_v_mps
            or abs(normalized["omega_rad_s"]) > max_omega_rad_s
        ):
            raise ValueError("command target exceeds its declared limit")
        return normalized

    def _existing_revision(self) -> int:
        path = self._config.path
        flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
        try:
            descriptor = os.open(path, flags)
        except FileNotFoundError:
            return 0
        except OSError as exc:
            raise ValueError("existing command mailbox cannot be opened safely") from exc
        try:
            metadata = os.fstat(descriptor)
            if not stat.S_ISREG(metadata.st_mode):
                raise ValueError("existing command mailbox must be a regular file")
            if metadata.st_uid != self._config.expected_uid:
                raise ValueError("existing command mailbox owner is not trusted")
            if stat.S_IMODE(metadata.st_mode) & 0o022:
                raise ValueError("existing command mailbox must not be group/world writable")
            if metadata.st_size > self._config.maximum_file_bytes:
                raise ValueError("existing command mailbox exceeds maximum_file_bytes")
            raw = os.read(descriptor, self._config.maximum_file_bytes + 1)
        finally:
            os.close(descriptor)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError("existing command mailbox must contain valid UTF-8 JSON") from exc
        if not isinstance(payload, dict) or payload.get("schema") != RESIDENT_COMMAND_SCHEMA:
            raise ValueError("existing command mailbox schema is invalid")
        return _positive_int(payload.get("revision"), "revision")

    def _atomic_write(self, encoded: bytes) -> None:
        path = self._config.path
        parent = path.parent
        if parent.is_symlink() or not parent.is_dir():
            raise ValueError("command mailbox parent must be a regular directory")
        temporary = parent / f".{path.name}.tmp.{os.getpid()}.{time.monotonic_ns()}"
        descriptor: int | None = None
        try:
            descriptor = os.open(
                temporary,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0),
                0o600,
            )
            view = memoryview(encoded)
            while view:
                written = os.write(descriptor, view)
                if written <= 0:
                    raise OSError("command mailbox write made no progress")
                view = view[written:]
            # This is an ephemeral, TTL-guarded mailbox rather than durable
            # storage. Atomic replacement provides the required reader
            # boundary; waiting for media durability here can make a command
            # stale before the resident process can observe it.
            os.close(descriptor)
            descriptor = None
            os.replace(temporary, path)
        finally:
            if descriptor is not None:
                os.close(descriptor)
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass


__all__ = [
    "AtomicResidentCommandGateway",
    "AsyncResidentCommandGateway",
    "RESIDENT_COMMAND_SCHEMA",
    "ResidentCommandClient",
    "ResidentCommandMailboxConfig",
]
